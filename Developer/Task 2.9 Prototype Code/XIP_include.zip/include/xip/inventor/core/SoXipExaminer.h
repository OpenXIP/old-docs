#ifndef SOXIPEXAMINER_H
#define SOXIPEXAMINER_H

#include <Inventor/nodekits/SoBaseKit.h>
#include <Inventor/fields/SoSFTrigger.h>
#include <Inventor/fields/SoSFBool.h>
#include <Inventor/fields/SoSFPlane.h>
#include <Inventor/fields/SoSFMatrix.h>
#include <Inventor/fields/SoSFFloat.h>
#include <Inventor/actions/SoActions.h>
#include <Inventor/events/SoMouseButtonEvent.h>
#include <Inventor/fields/SoSFVec3f.h>
#include <Inventor/fields/SoSFRotation.h>
#include <Inventor/SbLinear.h>
#include <Inventor/SoPickedPoint.h>
#include <vector>

#include <xip/inventor/core/xipivcore.h>


class SoFieldSensor;
class SoCamera;
class SbPlaneProjector;
class SbSphereSheetProjector;
class SoTimerSensor;


// utility class for grouping nodes of the intersection line geometry
class XIPIVCORE_API SoXipExaminer : public SoBaseKit 
{
	SO_KIT_HEADER(SoXipExaminer);

public:
	SoXipExaminer();
	static void initClass();

public:
	// Defines fields for the new parts in the catalog
	SO_KIT_CATALOG_ENTRY_HEADER(cameraSwitch);
	SO_KIT_CATALOG_ENTRY_HEADER(orthoCamera);
	SO_KIT_CATALOG_ENTRY_HEADER(perspectiveCamera);
	SO_KIT_CATALOG_ENTRY_HEADER(annotation);
	SO_KIT_CATALOG_ENTRY_HEADER(complexity);
	SO_KIT_CATALOG_ENTRY_HEADER(borderSwitch);
	SO_KIT_CATALOG_ENTRY_HEADER(borderNode);

	enum modeType {
		NONE,
		ROTATE,
		PANZOOM,
		ROTATE_PLANE,
		TRANSLATE_PLANE
	};

	enum orientationType {
		FEET,
		HEAD,
		LEFT,
		RIGHT,
		ANTERIOR,
		POSTERIOR,
		RANGE_START,
		RANGE_END,
		AZIMUTH_START,
		AZIMUTH_END,
		ELEVATION_START,
		ELEVATION_END
	};

	SoSFEnum mode;
	SoSFEnum orientation;
	SoSFTrigger viewOrientation;
	SoSFBool perspective;
	SoSFTrigger viewAll;
	SoSFTrigger resetPlane;
	SoSFBool pointTo;
	SoSFBool border;
	SoSFColor borderColor;
	SoSFBool autoSpin;

	// camera manipulation
	SoSFRotation rotateCamera;
	SoSFFloat scaleHeight;

	// outputs
	SoSFMatrix viewBoundingBox;
	SoSFPlane plane;

	SoSFVec3f pickedPoint;

	virtual void rotateCam(const SbRotation &rot);
	virtual void scaleCam(float scale);

	virtual void panCam(const SbVec2f pos);
	virtual void spinCam(const SbVec2f pos);
	virtual	void spinNormCam(const SbVec2f pos);
	virtual void rotatePlane(const SbRotation &rot);
	virtual void translatePlane(const SbVec3f &tvec);

public:
	virtual ~SoXipExaminer();
	virtual void inputChanged(SoField *which);
	virtual void timer(SoSensor *sensor);
	virtual SoCamera *getCamera();
	virtual void GLRender(SoGLRenderAction * action);
	virtual void handleEvent(SoHandleEventAction *action);
	virtual void updateCursor();

	// mouse/viewport handling
	virtual SbVec2f getMousePosNormalized(SoHandleEventAction *action);
	virtual void extractViewingParams(SoHandleEventAction *action);
	virtual void mouseRotatePlane(const SbVec2f &mousePos);
	virtual void mouseTranslatePlane(const SbVec2f &mousePos);
	virtual void scrollToCursor(SoHandleEventAction *action);


	std::vector<SoFieldSensor *> mInputSensors;
	SoTimerSensor *mTimerSensor;
	SbBool mViewAll;
	SbBool mResetPlane;
	SoMouseButtonEvent::Button mDragMouseButton;
	SbPlaneProjector *mPlaneProj;
	SbSphereSheetProjector *mSphereSheetProj;
	SbViewVolume mViewVolume;
	SbViewportRegion mVpRegion;
	SbMatrix mViewTransform;

	SbBool mDragStartMouseBorder;
	SbVec3f mDragStartMouse;
	SbVec3f mDragStartCameraPos;
	SbRotation mAutoSpinRotation;
	SbRotation *mRotBuffer;
	int mRotFirstIndex;
	int mRotLastIndex;
	SbVec2f mRotLastNormPos;
	SbTime mLastHandleEventTime;
	SbVec2f mLastMousePos;
	SbVec2f mMouseDownPos;
	SbBool mIsFirstMouseDown;

	struct mprPlanes_s
	{
		SoSFMatrix *matrixField;
		SoSFVec3f  *centerField;
	};
	typedef std::vector<mprPlanes_s> mprPlanes_t;
	mprPlanes_t mMprPlaneList;

private:
	SoHandleEventAction *mHandleEventAction;
	static void fieldSensorCBFunc(void *usr, SoSensor *sensor);
	static void timerSensorCBFunc(void *usr, SoSensor *sensor);
};


#endif // SOXIPEXAMINER_H
