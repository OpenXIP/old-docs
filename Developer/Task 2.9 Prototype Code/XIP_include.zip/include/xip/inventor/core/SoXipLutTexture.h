/**
 *	Node class to create an OpenGL texture from a
 *	lookup table
 */

#ifndef _SO_XIP_LUT_TEXTURE_H
#define _SO_XIP_LUT_TEXTURE_H

#include <xip/inventor/core/SoXipDataImage.h>
#include <Inventor/nodes/SoSubNode.h>
#include <Inventor/actions/SoGLRenderAction.h>

/**
 *	SoXipLutTexture. An Open Inventor node to create
 *	an OpenGL texture from a lookup table
 */
class XIPIVCORE_API SoXipLutTexture : public SoNode
{
	SO_NODE_HEADER( SoXipLutTexture );

public:
	/**
	 *	Constructor
	 */	
	SoXipLutTexture();

	/**	
	 *	Initializes the class
	 */
	static void initClass();

protected:
	/**
	 *	Destructor
	 */		
	~SoXipLutTexture();

	/**
	 *	Pointer to the input LUT image
	 */	
	SoXipDataImage*		m_imagePtr;
	/**
	 *	Has the texture been initialized ?
	 */	
	bool				m_textureInitialized;
	/**
	 *	The OpenGL texture's Id
	 */	
	unsigned int		m_textureId;
	/**
	 *	The Lookup Table image's Id
	 */	
    unsigned int        m_lutId;

	/**
	 *	GLRender
	 */
	void				GLRender(SoGLRenderAction *action);
	
	/**
	 *	Delete the OpenGL texture
	 */	
	void				deleteTexture();
	/**
	 *	Upload the OpenGL texture in video memory
	 */	
	void				loadTexture();
};

#endif