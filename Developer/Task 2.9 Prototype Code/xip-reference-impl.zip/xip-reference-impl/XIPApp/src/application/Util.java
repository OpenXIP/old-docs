/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package application;

import java.net.URI;
import java.util.UUID;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.NativeObjectDescriptor;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.NativeObjectLocator;


/**
 * @author Jaroslaw Krych
 *
 */
public class Util {

	
	public static NativeObjectDescriptor createNOD(){
		NativeObjectDescriptor nod = new NativeObjectDescriptor();				
		nod.setUUID(UUID.randomUUID().toString());
		nod.setMimeType("replace_with_actual_mime_type");
		nod.setSOPClassUID("replace_with_actual_SOPClassUID");
		return nod;
	}				

	
		
	public static NativeObjectLocator createNOL(NativeObjectDescriptor appNOD, URI uri){				
		NativeObjectLocator nol = new NativeObjectLocator();
		nol.setUUID(appNOD.getUUID());		
		nol.setURI(uri.toString());										
		return nol;		
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
