/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package application;

import java.net.URL;
import javax.xml.ws.Endpoint;
import org.nema.dicom.wg23.clientToHost.ClientToHost;
import org.nema.dicom.wg23.Application;

/**
 * <font  face="Tahoma" size="2">
 * Creates new instance of XIP Application. <br></br>
 * It contains client to host.<br></br>
 * @version	January 2008
 * @author Jaroslaw Krych
 * </font>
 */
public class XIPApplication {
	ClientToHost client; 
	Application appInterfaceImpl = new Application();
	Endpoint endpoint;
	/**
	 * Constracts XIP application.
	 * It contains a client to XIP Host.
	 * It contains implementations of WG23 interface methods
	 */
	public XIPApplication (URL hostURL, URL appURL){		
		//8060-8073   Unassigned port numbers
		//Must make sure port 8060 is not used
		//If used catch error and assign port number = old port number + 1		
		
		String appEPR = appURL.toString();
		//System.out.println("Application EPR: " + appEPR);	
		endpoint = Endpoint.publish(appEPR, appInterfaceImpl);						
		client = new ClientToHost(hostURL);	
	}
	
	public Application getApplicationInterfaceImpl(){
		return appInterfaceImpl;
	}
	
	public ClientToHost getClientToHost(){
		return client;
	}
	
	public Endpoint getEndPoint(){
		return endpoint;
	}
}
