/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package application;

import java.io.File;
import java.io.IOException;
import com.pixelmed.dicom.AttributeList;
import com.pixelmed.dicom.DicomException;
import com.pixelmed.dicom.TagFromName;

/**
 * <font  face="Tahoma" size="2">
 * Parses DICOM file and retrieves commonly used attribues.<br></br>
 * @version	January 2008
 * @author Jaroslaw Krych
 * </font>
 */
public class BasicDicomParser {
	String strFileDir = new String();
	AttributeList list = new AttributeList();
	String strPatient = new String();
	String strStudy = new String();
	String strSeries = new String();
	String strSOPClassUID = new String();
	String strStudyDate = new String();
	String strContentDate = new String();
	String strSeriesDate = new String();
	String strStudyInstanceUID = new String();
	String strBitsStored = new String();
	
	public AttributeList parseDicom(File dicomFile){
		try {			
			String strPath = dicomFile.getPath();			
			list.read(strPath,null,true,true);
		} catch (IOException e) {			
			/*new ExceptionDialog("DICOM Exception!", 
					dicomFile.getName() + " is not DICOM file!",
					"Data for this file will not be saved.");*/
			e.printStackTrace();
		} catch (DicomException e) {		
			e.printStackTrace();
		}				
		return list;
	}
    
	public String getPatient(){
		strPatient = list.get(TagFromName.PatientName).getDelimitedStringValuesOrEmptyString();
		return strPatient;
	}
	
	public String getStudy(){
		strStudy = list.get(TagFromName.StudyDescription).getDelimitedStringValuesOrEmptyString();
		return strStudy;
		
	}
	public String getStudyInstanceUID(){
		strStudyInstanceUID = list.get(TagFromName.StudyInstanceUID).getDelimitedStringValuesOrEmptyString();
		return strStudyInstanceUID;
	}
	
	public String getSeries(){
		strSeries = list.get(TagFromName.SeriesInstanceUID).getDelimitedStringValuesOrEmptyString();
		return strSeries;
	}
	
	public String getSOPClassUID(){
		strSOPClassUID =list.get(TagFromName.SOPClassUID).getDelimitedStringValuesOrEmptyString();
		return strSOPClassUID;
	}
	
	public String getStudyDate(){
		strStudyDate = list.get(TagFromName.StudyDate).getDelimitedStringValuesOrEmptyString();
		return strStudyDate;
	}
	
	public String getContentDate(){
		strContentDate = list.get(TagFromName.ContentDate).getDelimitedStringValuesOrEmptyString();
		return strContentDate;
	}
	
	public String getSeriesDate(){
		strSeriesDate = list.get(TagFromName.SeriesDate).getDelimitedStringValuesOrEmptyString();
		return strSeriesDate;
	}
	
	public String getBitsStored(){
		strBitsStored = list.get(TagFromName.BitsStored).getDelimitedStringValuesOrEmptyString();
		return strBitsStored;
	}
	
	public String getImagePositionPatient(){
		return list.get(TagFromName.ImagePositionPatient).getDelimitedStringValuesOrEmptyString();		
	}
	
	public void setFileDir(String fileDir){
		strFileDir = fileDir;
	}
	
	/*public AttributeList getShortAttributeList(AttributeList fullAttributeList){
		AttributeList attList = new AttributeList();
		String[] characterSets = { "ISO_IR 100" };
		SpecificCharacterSet specificCharacterSet = new SpecificCharacterSet(characterSets);
		try{
			{ AttributeTag t = TagFromName.PatientName; Attribute a = new PersonNameAttribute(t,specificCharacterSet); a.addValue(fullAttributeList.get(TagFromName.PatientName).getDelimitedStringValuesOrEmptyString()); attList.put(t,a); }
			{ AttributeTag t = TagFromName.PatientID; Attribute a = new ShortStringAttribute(t,specificCharacterSet); attList.put(t,a); }
			{ AttributeTag t = TagFromName.StudyInstanceUID; Attribute a = new UniqueIdentifierAttribute(t); attList.put(t,a); }		
			{ AttributeTag t = TagFromName.SeriesInstanceUID; Attribute a = new UniqueIdentifierAttribute(t); a.addValue(fullAttributeList.get(TagFromName.SeriesInstanceUID).getDelimitedStringValuesOrEmptyString()); attList.put(t,a); }
			{ AttributeTag t = TagFromName.SOPInstanceUID; Attribute a = new UniqueIdentifierAttribute(t); a.addValue(fullAttributeList.get(TagFromName.SOPClassUID).getDelimitedStringValuesOrEmptyString()); attList.put(t,a); }
			
		}catch (DicomException e){
			
		}
		return attList;
	}
	
	*/
	
	String sopInstanceUID;
	public String getSOPInstanceUID(){
		sopInstanceUID = list.get(TagFromName.SOPInstanceUID).getDelimitedStringValuesOrEmptyString();
		return sopInstanceUID;
	}
	public static void main (String [] args){
		BasicDicomParser parser = new BasicDicomParser();
		/*parser.parseDicom(new File("C:\\WUSTL\\Tmp\\GroupingTest\\1.3.6.1.4.1.9328.50.1.1203.dcm"));
		String strDate = parser.getStudyDate();
		//Change format
		String strYear = strDate.substring(0, 4);
		String strMonth = strDate.substring(4, 6);
		String strDay = strDate.substring(6, 8);
				
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date date1 = null;		
        try {
			date1 = (Date)formatter.parse(strMonth + "/" + strDay + "/" + strYear);
			System.out.println(date1);			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	*/
		//parser.parseDicom(new File("C:/WUSTL/Tmp/GroupingTest3/1/MR1S1IM1.dcm"));
		//parser.parseDicom(new File("C:/WUSTL/Tmp/DICOM-TEST260.tmp/IN000349"));
		
		/*parser.parseDicom(new File("C:/WUSTL/XIP_Admin/AIM/aim_11_13_2007/AIM-Sample-Instances/Images/CT.1.3.6.1.4.1.9328.50.1.8956.dcm"));
		System.out.println(parser.getImagePositionPatient());
		String str = parser.getImagePositionPatient();
		StringTokenizer st = new StringTokenizer(str, "\\");
		while (st.hasMoreTokens()) {
	         System.out.println(st.nextToken());
	     }*/
		
		/*parser.parseDicom(new File("C:/WUSTL/Tmp/DICOM-TEST260.tmp/1.3.6.1.4.1.9328.50.1.1199.dcm"));
		System.out.println(parser.getSOPClassUID());
		System.out.println(parser.getSOPInstanceUID());
		System.out.println(parser.getStudyInstanceUID());
		System.out.println(parser.getSeries());*/
		parser.parseDicom(new File("C:/WUSTL/XIP_Admin/AIM/AIM-Sample-Instances_11_21_2007/Images/Follow-up/CT.1.3.6.1.4.1.9328.50.1.9208.dcm"));
		System.out.println(parser.getSOPClassUID());
		System.out.println(parser.getSOPInstanceUID());
		System.out.println(parser.getStudyInstanceUID());
		System.out.println(parser.getSeries());
	}
}
