import javax.swing.JPanel;
import javax.swing.JWindow;

/*
 * Main.java
 *
 */

/**
 *
 * @author Ranajoy Malakar
 */

public class RunIvJava {
    	
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        MainFrame myForm = new MainFrame();
        myForm.setSize(625,675);
		//myForm.setLocationRelativeTo(null);
		myForm.setVisible(true);
    	
        
    }
    
}
