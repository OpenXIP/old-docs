
package org.nema.dicom.wg23.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.nema.dicom.wg23.Rectangle;

@XmlRootElement(name = "getAvailableScreen", namespace = "http://wg23.dicom.nema.org/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getAvailableScreen", namespace = "http://wg23.dicom.nema.org/")
public class GetAvailableScreen {

    @XmlElement(name = "arg0", namespace = "")
    private Rectangle arg0;

    /**
     * 
     * @return
     *     returns Rectangle
     */
    public Rectangle getArg0() {
        return this.arg0;
    }

    /**
     * 
     * @param arg0
     *     the value for the arg0 property
     */
    public void setArg0(Rectangle arg0) {
        this.arg0 = arg0;
    }

}
