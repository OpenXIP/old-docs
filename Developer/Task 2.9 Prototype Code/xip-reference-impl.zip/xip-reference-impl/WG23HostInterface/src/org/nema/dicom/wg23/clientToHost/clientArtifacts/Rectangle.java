
package org.nema.dicom.wg23.clientToHost.clientArtifacts;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for rectangle complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="rectangle">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="refPointX" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="refPointY" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="screenHeight" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="screenWidth" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rectangle", propOrder = {
    "refPointX",
    "refPointY",
    "screenHeight",
    "screenWidth"
})
public class Rectangle {

    protected int refPointX;
    protected int refPointY;
    protected int screenHeight;
    protected int screenWidth;

    /**
     * Gets the value of the refPointX property.
     * 
     */
    public int getRefPointX() {
        return refPointX;
    }

    /**
     * Sets the value of the refPointX property.
     * 
     */
    public void setRefPointX(int value) {
        this.refPointX = value;
    }

    /**
     * Gets the value of the refPointY property.
     * 
     */
    public int getRefPointY() {
        return refPointY;
    }

    /**
     * Sets the value of the refPointY property.
     * 
     */
    public void setRefPointY(int value) {
        this.refPointY = value;
    }

    /**
     * Gets the value of the screenHeight property.
     * 
     */
    public int getScreenHeight() {
        return screenHeight;
    }

    /**
     * Sets the value of the screenHeight property.
     * 
     */
    public void setScreenHeight(int value) {
        this.screenHeight = value;
    }

    /**
     * Gets the value of the screenWidth property.
     * 
     */
    public int getScreenWidth() {
        return screenWidth;
    }

    /**
     * Sets the value of the screenWidth property.
     * 
     */
    public void setScreenWidth(int value) {
        this.screenWidth = value;
    }

}
