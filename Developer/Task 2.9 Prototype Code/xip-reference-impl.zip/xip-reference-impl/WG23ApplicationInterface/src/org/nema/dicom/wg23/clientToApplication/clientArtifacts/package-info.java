@javax.xml.bind.annotation.XmlSchema(namespace = "http://wg23.dicom.nema.org/")
package org.nema.dicom.wg23.clientToApplication.clientArtifacts;
