/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23;

/**
 * @author Jaroslaw Krych
 *
 */
public class Status {	
	
	StatusType statusType;
	String codingSchemeDesignator;
	int codeValue;
	String message;
	
	public StatusType getStatusType(){
		return statusType;
	}
	public void setStatusType(StatusType statusType){
		this.statusType = statusType;
	}
	public String getCodingSchemeDesignator(){
		return codingSchemeDesignator;
	}
	public void setCodingSchemeDesignator(String codingSchemeDesignator){
		this.codingSchemeDesignator = codingSchemeDesignator;
	}
	public int getCodeValue(){
		return codeValue;
	}
	public void setCodeValue(int codeValue){
		this.codeValue = codeValue;
	}
	public String getMessage(){
		return message;
	}
	public void setMessage(String message){
		this.message = message;
	}
}
