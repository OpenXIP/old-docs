
package org.nema.dicom.wg23.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.nema.dicom.wg23.NativeObjectLocator;

@XmlRootElement(name = "getAsFileResponse", namespace = "http://wg23.dicom.nema.org/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getAsFileResponse", namespace = "http://wg23.dicom.nema.org/")
public class GetAsFileResponse {

    @XmlElement(name = "return", namespace = "")
    private NativeObjectLocator[] _return;

    /**
     * 
     * @return
     *     returns NativeObjectLocator[]
     */
    public NativeObjectLocator[] get_return() {
        return this._return;
    }

    /**
     * 
     * @param _return
     *     the value for the _return property
     */
    public void set_return(NativeObjectLocator[] _return) {
        this._return = _return;
    }

}
