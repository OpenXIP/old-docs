#include <Inventor/actions/SoGLRenderAction.h>
#include <Inventor/errors/SoDebugError.h>
#include <xip/inventor/core/SoXipMultiTextureElement.h>
#include <windows.h>
#include <GL/gl.h>
#include <gl/glext.h>

static PFNGLACTIVETEXTUREARBPROC glActiveTextureARB = 0;


#undef DEBUG

#ifdef DEBUG
#define FUNCID(...) SoDebugError::postInfo(__FUNCTION__, __VA_ARGS__);
#else
#define FUNCID(...)
#endif

SO_ELEMENT_SOURCE(SoXipMultiTextureElement);

SoXipMultiTextureElement::~SoXipMultiTextureElement() {
	FUNCID("Deleting array, textures = %p", textures);
	delete [] textures;
}

void SoXipMultiTextureElement::initClass() {
	SO_ELEMENT_INIT_CLASS(SoXipMultiTextureElement, SoElement);
}

SbBool SoXipMultiTextureElement::matches(const SoElement *element) const {
	FUNCID("");
	return false;
	//if (getTypeId() != element->getTypeId())
	//	return FALSE;
	//for(int i = NB_TEXTURE_MAX - 1; i >= 0; i--)
	//{
	//	if(((const SoXipMultiTextureElement *) element)->enabled[i] != this->enabled[i])
	//		return FALSE;
	//}
	//if (((const SoXipMultiTextureElement *) element)->last!=this->last)
	//	return FALSE;
	//return TRUE;
}

SoElement* SoXipMultiTextureElement::copyMatchInfo() const {
	FUNCID("");

	SoXipMultiTextureElement *element = (SoXipMultiTextureElement*)(getTypeId().createInstance());

	//for(int i = NB_TEXTURE_MAX - 1; i >= 0; i--)
	//	element->enabled[i]=this->enabled[i];
	//element->last = this->last;
	return (SoElement *)element;
}

void SoXipMultiTextureElement::init(SoState *state) {
	FUNCID("textures = %p", textures);

	//glGetIntegerv(GL_MAX_TEXTURE_UNITS, &numUnits);
	glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &numUnits);

	//SoDebugError::postInfo(__FUNCTION__, "Max texture units: %d", numUnits);

	if (numUnits <= 0) {
		numUnits = 1;
	}
	else if (numUnits > 32) {
		numUnits = 32;
	}

	textures = new textureInfo[numUnits];

	for (int i = 0; i < numUnits; i++) {
		textures[i] = textureInfo(0, 0);
	}

	currentUnit = 0;

	// Tell pushed child to init
	initChild = true;
}

void SoXipMultiTextureElement::push(SoState *state) {
	FUNCID("");
	SoXipMultiTextureElement *prev = (SoXipMultiTextureElement*)(this->getNextInStack());

	// This should run once per instance, as a constructor
	if (prev->initChild) {
		FUNCID("Initting with textures = %p", textures);

		numUnits = prev->numUnits;

		textures = new textureInfo[numUnits];

		// Tell pushed child to init
		initChild = true;

		// Done initializing this child
		prev->initChild = false;
	}

	for (int i = 0; i < numUnits; i++) {
		textures[i] = prev->textures[i];
	}

	currentUnit = prev->currentUnit;
	unitsChanged = 0;

	//prev->capture(state);
}

void SoXipMultiTextureElement::pop(SoState *state, const SoElement *prevTopElement) {
	FUNCID("");
	SoXipMultiTextureElement *prev = (SoXipMultiTextureElement*)prevTopElement;

	// only check for changed ones...
	for (int i = 0; i < numUnits; i++) {
		if (prev->unitsChanged & (1 << i)) {
			FUNCID("Restoring changed unit %d", i);
			setUnitGL(i);
			prev->unbindTextureGL(i);
			if (textures[i].target != 0)
				bindTextureGL(i);
		}
	}

	setUnitGL(currentUnit);
}

void SoXipMultiTextureElement::setUnit(SoState *state, GLuint unit) {
	SoXipMultiTextureElement *element = (SoXipMultiTextureElement*)getElement(state, classStackIndex);

	if (element) {
		element->setUnitElt(unit);
	}
}

void SoXipMultiTextureElement::setUnitElt(GLuint unit) {
	currentUnit = unit;

	setUnitGL(currentUnit);
}

void SoXipMultiTextureElement::setUnitGL(GLuint unit) {
	FUNCID("unit = %d", unit);

	if (!glActiveTextureARB)
	    glActiveTextureARB = (PFNGLACTIVETEXTUREARBPROC) wglGetProcAddress("glActiveTextureARB");

    if (glActiveTextureARB)
    {
		glActiveTextureARB((unsigned int) GL_TEXTURE0 + unit);
    }
}

void SoXipMultiTextureElement::bindTexture(SoState *state, GLenum target, GLuint id) {
	SoXipMultiTextureElement *element = (SoXipMultiTextureElement*)getElement(state, classStackIndex);

	if (element) {
		element->bindTextureElt(target, id);
	}
}

void SoXipMultiTextureElement::bindTextureCurrUnit(SoState *state) {

	SoXipMultiTextureElement *element = (SoXipMultiTextureElement*)getElement(state, classStackIndex);

	if (element) {
    element->bindTextureElt(element->textures[element->currentUnit].target, 
                            element->textures[element->currentUnit].id);
	}
}

void SoXipMultiTextureElement::bindTextureElt(GLenum target, GLuint id) {
	textures[currentUnit].target = target;
	textures[currentUnit].id = id;

	bindTextureGL(currentUnit);

	unitsChanged |= 1 << currentUnit;
}

void SoXipMultiTextureElement::bindTextureGL(GLuint unit) {
	FUNCID("target = %d, id = %d", textures[unit].target, textures[unit].id);
	glBindTexture(textures[unit].target, textures[unit].id);
}

void SoXipMultiTextureElement::unbindTextureGL(GLuint unit) {
	FUNCID("target = %d id = %d", textures[unit].target, textures[unit].id);
	glBindTexture(textures[unit].target, 0);
}

GLuint SoXipMultiTextureElement::getFreeUnit(SoState *state) {
	const SoXipMultiTextureElement *element = (const SoXipMultiTextureElement*)getConstElement(state, classStackIndex);

	if (element) {
		return element->getFreeUnitElt();
	}

	return 0;
}

GLuint SoXipMultiTextureElement::getFreeUnitElt() const {
	for (int i = 0; i < numUnits; i++) {
		if (textures[i].target == 0) {
			return i;
		}
	}

	SoDebugError::post(__FUNCTION__, "Cannot find unused texture unit (max %d units used), defaulting to unit 0.", numUnits);
	return 0;
}

GLuint SoXipMultiTextureElement::getCurrentUnit(SoState *state) {
	const SoXipMultiTextureElement *element = (const SoXipMultiTextureElement*)getConstElement(state, classStackIndex);

	if (element) {
		return element->getCurrentUnitElt();
	}

	return 0;
}

GLuint SoXipMultiTextureElement::getCurrentUnitElt() const {
	return currentUnit;
}