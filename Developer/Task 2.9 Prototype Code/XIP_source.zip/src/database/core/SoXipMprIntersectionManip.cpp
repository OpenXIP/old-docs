#include "SoXipMprIntersectionManip.h"
#include <xip/inventor/coregl/SoXipGLOWElement.h>
#include <Inventor/actions/SoGLRenderAction.h>
#include <Inventor/actions/SoPickAction.h>
#include <Inventor/actions/SoCallbackAction.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoDrawStyle.h>
#include <Inventor/nodes/SoLineSet.h>
#include <Inventor/nodes/SoBaseColor.h>
#include <Inventor/sensors/SoFieldSensor.h>
#include <Inventor/elements/SoClipPlaneElement.h>
#include <Inventor/fields/SoSFMatrix.h>
#include <Inventor/events/SoMouseButtonEvent.h>
#include <Inventor/events/SoLocation2Event.h>
#include <Inventor/actions/SoHandleEventAction.h>
#include <Inventor/SoPickedPoint.h>
#include <Inventor/projectors/SbPlaneProjector.h>
#include <Inventor/errors/SoDebugError.h>
#include <xip/inventor/core/SoXipCursor.h>
#include <xip/inventor/core/SoXipMprPlaneElement.h>
#include <xip/inventor/core/SoXipMprActiveElement.h>
#include <assert.h>
#include <xip/inventor/core/XipInventorUtils.h>
#include "SoXipMprIntersectionLine.h"



SO_NODE_SOURCE(SoXipMprIntersectionManip);


SoXipMprIntersectionManip::SoXipMprIntersectionManip()
{
	SO_NODE_CONSTRUCTOR(SoXipMprIntersectionManip);

	mPickedLine = -1;

	SO_NODE_DEFINE_ENUM_VALUE(modeType, INTERSECTION);
	SO_NODE_DEFINE_ENUM_VALUE(modeType, FREE);
	SO_NODE_SET_SF_ENUM_TYPE(mode, modeType);

	SO_NODE_ADD_FIELD(on, (TRUE));
	SO_NODE_ADD_FIELD(mode, (INTERSECTION));

	mModeFieldSensor = new SoFieldSensor(&fieldSensorCBFunc, this);
	mModeFieldSensor->attach(&mode);
}


SoXipMprIntersectionManip::~SoXipMprIntersectionManip()
{
	delete mModeFieldSensor;
}


void SoXipMprIntersectionManip::initClass()
{
	SO_NODE_INIT_CLASS(SoXipMprIntersectionManip, SoXipPlaneManipBase, "SoXipPlaneManipBase");

	SO_ENABLE(SoGLRenderAction, SoXipMprPlaneElement);
	SO_ENABLE(SoPickAction,     SoXipMprPlaneElement);
	SO_ENABLE(SoCallbackAction, SoXipMprPlaneElement);
	SO_ENABLE(SoHandleEventAction, SoXipMprPlaneElement);

	SO_ENABLE(SoGLRenderAction, SoXipMprActiveElement);
	SO_ENABLE(SoPickAction,     SoXipMprActiveElement);
	SO_ENABLE(SoCallbackAction, SoXipMprActiveElement);
	SO_ENABLE(SoHandleEventAction, SoXipMprActiveElement);
}


void SoXipMprIntersectionManip::fieldSensorCBFunc(void *user, SoSensor *sensor)
{
	SoXipMprIntersectionManip *obj = (SoXipMprIntersectionManip*) user;

	if (obj)
	{
		obj->fieldSensorCB(sensor);
	}
}


void SoXipMprIntersectionManip::fieldSensorCB(SoSensor *sensor)
{
	mPickedLine = -1;
	mMprPlaneList.clear();
	removeAllChildren();
}


void SoXipMprIntersectionManip::GLRender(SoGLRenderAction * action)
{
	if (on.getValue())
	{
		updateElement(action);

		GLboolean depthTestEnabled = glIsEnabled(GL_DEPTH_TEST);
		glDisable(GL_DEPTH_TEST);

		SoXipPlaneManipBase::GLRender(action);

		if (depthTestEnabled)
			glEnable(GL_DEPTH_TEST);
	}
}


void SoXipMprIntersectionManip::callback(SoCallbackAction *action)
{
	if (on.getValue())
	{
		updateElement(action);
		SoXipPlaneManipBase::callback(action);
	}
}


void SoXipMprIntersectionManip::pick(SoPickAction *action)
{
	if (on.getValue())
	{
		updateElement(action);
		SoXipPlaneManipBase::pick(action);
	}
}


void SoXipMprIntersectionManip::getBoundingBox(SoGetBoundingBoxAction *action)
{
	if (on.getValue())
	{
		SoXipPlaneManipBase::getBoundingBox(action);
	}
}


void SoXipMprIntersectionManip::updateElement(SoAction * action)
{
	int i;
	assert(action != 0);

	// check state
	SoState *state = action->getState();
	if (!state) return;

	SoXipMprPlaneElement *element = SoXipMprPlaneElement::getInstance(state);
	if (!element) return;

	int numPlanes = element->getNum();
	int basePlane = numPlanes - 1;

	/* not sure what this block was for but it causes a crash with the IFE network image
	// let's just comment it out for now and simply return while dragging (found in revision 916)
  
	// while dragging, only update MPR elements
	if (mPickedLine >= 0) 
	{
		SbVec3f movement = getMouseProjection() - mPickPosition;

		// translate all MPR planes to new mouse position
		for (i = 0; i < mMprPlaneList.size(); i++)
		{
			SbMatrix m = XipGeomUtils::translatePlaneNormal(mMprPlaneList[i].matrix, movement);
			element->setMatrix(i, m);
		}

		return;
	}	*/

	// do not update while dragging
	if (mPickedLine >= 0) return;


	// first, check if anything has changed
	if (numPlanes == mMprPlaneList.size())
	{
		for (i = 0; i < numPlanes; i++)
		{
			if (!mMprPlaneList[i].matrix.equals(element->getMatrix(i), XIP_FLT_EPSILON) ||
				!mMprPlaneList[i].center.equals(element->getCenter(i), XIP_FLT_EPSILON) ||
				(mMprPlaneList[i].id != element->getId(i)) ||
				(mMprPlaneList[i].color != element->getColor(i))) break;
		}

		// no change in any of the matrices
		if (i == mMprPlaneList.size()) return;
	}

	// copy updated elements into member variable
	mMprPlaneList.resize(numPlanes);
	for (i = 0; i < numPlanes; i++)
	{
		mMprPlaneList[i].node = 0;
		mMprPlaneList[i].matrix = element->getMatrix(i);
		mMprPlaneList[i].center = element->getCenter(i);
		mMprPlaneList[i].color = element->getColor(i);
		mMprPlaneList[i].matrixField = element->getMatrixField(i);
		mMprPlaneList[i].centerField = element->getCenterField(i);
		mMprPlaneList[i].id = element->getId(i);
	}

	// update projection plane
	if (basePlane >= 0)
		setPlane(XipGeomUtils::planeFromMatrix(mMprPlaneList[basePlane].matrix));

	// update current geometry
	updateGeometry();
}


void SoXipMprIntersectionManip::updateGeometry()
{
	int i;
	SbMatrix planeMatrix;
	SbBool hasIntersectionPoint = FALSE;
	int numPlanes = mMprPlaneList.size();
	int basePlane = numPlanes - 1;

	// clear current geometry first
	removeAllChildren();

	// can't compute intersection lines with less than 2 planes
	// or invalid base plane
	if ((numPlanes < 2) || (basePlane < 0) || (basePlane >= numPlanes)) return;

	planeMatrix = mMprPlaneList[basePlane].matrix;


	// compute intersection point of 3 planes
	if ((mode.getValue() == INTERSECTION) && (numPlanes > 2))
	{
		hasIntersectionPoint = XipGeomUtils::planeIntersect(
			XipGeomUtils::planeFromMatrix(mMprPlaneList[0].matrix),
			XipGeomUtils::planeFromMatrix(mMprPlaneList[1].matrix),
			XipGeomUtils::planeFromMatrix(mMprPlaneList[2].matrix),
			mIntersectionPosition);

		if (hasIntersectionPoint)
		{
			// update center on all planes
			for (i = 0; i < numPlanes; i++)
			{
				if (mMprPlaneList[i].centerField && !mMprPlaneList[i].center.equals(mIntersectionPosition, XIP_FLT_EPSILON))
				{
					mMprPlaneList[i].centerField->setValue(mIntersectionPosition);
				}
			}
		}
	}

	// create new geometry
	for (i = 0; i < numPlanes; i++)
	{
		if (i != basePlane)
		{
			// will be referenced by addChild() and unreferenced/deleted by removeAllChildren()
			mMprPlaneList[i].node = new SoXipMprIntersectionLine();

			SoBaseColor *col = SO_GET_PART(mMprPlaneList[i].node, "color", SoBaseColor);
			col->rgb.setValue(mMprPlaneList[i].color);

			if (hasIntersectionPoint)
			{
				mMprPlaneList[i].node->centerPosition.setValue(mIntersectionPosition);
				mMprPlaneList[i].node->centerGap.setValue(TRUE);
			}
			else
			{
				// project center point on intersection line (closest point)
				SbVec3f point = projectCenterOnPlane(mMprPlaneList[i].matrix, mMprPlaneList[i].center);
				mMprPlaneList[i].node->centerPosition.setValue(point);

				mMprPlaneList[i].node->centerGap.setValue(TRUE);
				mMprPlaneList[i].node->centerCross.setValue(TRUE);
			}

			mMprPlaneList[i].node->planeMatrix.setValue(planeMatrix);
			mMprPlaneList[i].node->intersectMatrix.setValue(mMprPlaneList[i].matrix);

			addChild(mMprPlaneList[i].node);
		}
	}
}


SbBool SoXipMprIntersectionManip::dragBegin()
{
	if (mPickedLine >= 0) return TRUE;

	updateElement(mHandleEventAction);

	// if there are no planes there is nothing to do
	if (mMprPlaneList.size() <= 0) return FALSE;

	mPickedCenter = FALSE;
	mPickedLine = getPickedLine();

	if (mPickedLine >= 0)
	{
		mPickPosition = getMouseProjection();
		updateProjectors(mPickPosition);

		mHandleEventAction->setGrabber(this);

		if (mPickedLine >= (int)mMprPlaneList.size())
		{
			SoDebugError::post(__FILE__, "Picked line greater array size!\n");
			mPickedLine = FALSE;
			return FALSE;
		}

		if (SoXipMprActiveElement::getMprIndex(mHandleEventAction->getState()) != mMprPlaneList[mPickedLine].id)
		{
			// need to update active MPR element
			SoSFInt32 *field = SoXipMprActiveElement::getMprFieldIndex(mHandleEventAction->getState());
			if (field)
			{
				field->setValue(mMprPlaneList[mPickedLine].id);
			}

			SoXipMprActiveElement::set(mHandleEventAction->getState(), this, mMprPlaneList[mPickedLine].id, field);
		}

		// if in INTERSECTION mode, check if center point was picked
		if ((mode.getValue() == INTERSECTION) && (mMprPlaneList.size() > 2))
		{
			SbVec3f obj[2];
			int basePlane = mMprPlaneList.size() - 1;
			SbMatrix worldToObj = mMprPlaneList[basePlane].matrix.inverse();
			worldToObj.multVecMatrix(mPickPosition, obj[0]);
			worldToObj.multVecMatrix(mIntersectionPosition, obj[1]);

			if (XipGeomUtils::isVecInObjectSpace(obj[0] - obj[1], 0.06))
			{
				mPickedCenter = TRUE;
			}
		}
		else
		{
			// free mode, check if center or off-center (rotate)
			mRotatePosition = projectCenterOnPlane(mMprPlaneList[mPickedLine].matrix, mMprPlaneList[mPickedLine].center);

			SbVec3f obj[2];
			int basePlane = mMprPlaneList.size() - 1;
			SbMatrix worldToObj = mMprPlaneList[basePlane].matrix.inverse();

			worldToObj.multVecMatrix(mPickPosition, obj[0]);
			worldToObj.multVecMatrix(mRotatePosition, obj[1]);

			if (XipGeomUtils::isVecInObjectSpace(obj[0] - obj[1], 0.25))
			{
				mPickedCenter = TRUE;
			}
		}

		return TRUE;
	}
	else
	{
		// picked base plane
		int basePlane = mMprPlaneList.size() - 1;

		if (SoXipMprActiveElement::getMprIndex(mHandleEventAction->getState()) != mMprPlaneList[basePlane].id)
		{
			// need to update active MPR element
			SoSFInt32 *field = SoXipMprActiveElement::getMprFieldIndex(mHandleEventAction->getState());
			if (field)
			{
				field->setValue(mMprPlaneList[basePlane].id);
			}

			SoXipMprActiveElement::set(mHandleEventAction->getState(), this, mMprPlaneList[basePlane].id, field);
		}
	}

	return FALSE;
}


SbBool SoXipMprIntersectionManip::dragMove()
{
	if (mPickedLine >= 0)
	{
		switch (mode.getValue())
		{
		case FREE:
			dragMoveFree();			
			break;

		case INTERSECTION:
			if (mMprPlaneList.size() > 2)
			{
				dragMoveIntersection();
			}
			else
			{
				dragMoveFree();
			}
			break;
		}
	}

	return SoXipPlaneManipBase::dragMove();
}


void SoXipMprIntersectionManip::dragMoveFree()
{
	if (mMprPlaneList.size() <= 0) return;

	if (mPickedCenter)
	{
		// translate
		SbVec3f movement = getMouseProjection() - mPickPosition;
		SbMatrix m = XipGeomUtils::translatePlaneNormal(mMprPlaneList[mPickedLine].matrix, movement);
		SbVec3f c = mMprPlaneList[mPickedLine].center + movement;
		SbVec3f point = projectCenterOnPlane(m, c);

		mMprPlaneList[mPickedLine].node->intersectMatrix.setValue(m);
		mMprPlaneList[mPickedLine].node->centerPosition.setValue(point);

		// update fields
		if (mMprPlaneList[mPickedLine].matrixField)
		{
			if (!mMprPlaneList[mPickedLine].matrixField->getValue().equals(m, XIP_FLT_EPSILON))
			{
				mMprPlaneList[mPickedLine].matrixField->setValue(m);
			}
		}

		if (mMprPlaneList[mPickedLine].centerField)
		{
			if (!mMprPlaneList[mPickedLine].centerField->getValue().equals(c, XIP_FLT_EPSILON))
			{
				mMprPlaneList[mPickedLine].centerField->setValue(c);
			}
		}
	}
	else
	{
		// rotate
		SbVec3f mousePos = getMouseProjection();
		int basePlane = mMprPlaneList.size() - 1;
		SbVec3f center = mRotatePosition;
		SbLine line;

		if (XipGeomUtils::planeIntersect(XipGeomUtils::planeFromMatrix(mMprPlaneList[basePlane].matrix), XipGeomUtils::planeFromMatrix(mMprPlaneList[mPickedLine].matrix), line))
		{
			float rad;
			SbVec3f axis;
			SbRotation fromToRot;

			SbVec3f n1 = line.getDirection(), n2 = mousePos - center;
			n2.normalize();
			fromToRot.setValue(n1, n2);
			fromToRot.getValue(axis, rad);

			if (rad > (M_PI / 2))
			{
				// adjust rotation around current axis to avoid flip in direction
				fromToRot.setValue(axis, rad - M_PI);
			}

			// rotate the picked line
			SbMatrix m = mMprPlaneList[mPickedLine].matrix;
			SbMatrix rot, trans;
			rot.setRotate(fromToRot);
			trans.setTranslate(-center);

			m *= trans;
			m *= rot;
			m *= trans.inverse();

			mMprPlaneList[mPickedLine].node->intersectMatrix.setValue(m);
			mMprPlaneList[mPickedLine].matrix = m;

			if (mMprPlaneList[mPickedLine].matrixField)
			{
				if (!mMprPlaneList[mPickedLine].matrixField->getValue().equals(m, XIP_FLT_EPSILON))
				{
					mMprPlaneList[mPickedLine].matrixField->setValue(m);
				}
			}
		}
	}
}


void SoXipMprIntersectionManip::dragMoveIntersection()
{
	int i;
	SbVec3f movement = getMouseProjection() - mPickPosition;

	if (!mPickedCenter)
	{
		// translate only the picked line
		SbMatrix m = XipGeomUtils::translatePlaneNormal(mMprPlaneList[mPickedLine].matrix, movement);
		mMprPlaneList[mPickedLine].node->intersectMatrix.setValue(m);

		if (mMprPlaneList[mPickedLine].matrixField)
		{
			if (!mMprPlaneList[mPickedLine].matrixField->getValue().equals(m, XIP_FLT_EPSILON))
			{
				mMprPlaneList[mPickedLine].matrixField->setValue(m);
			}
		}

		// compute new intersection point
		SbVec3f intersectionPoint;
		if (XipGeomUtils::planeIntersect(
				XipGeomUtils::planeFromMatrix(m),
				XipGeomUtils::planeFromMatrix(mMprPlaneList[(mPickedLine + 1) % 3].matrix),
				XipGeomUtils::planeFromMatrix(mMprPlaneList[(mPickedLine + 2) % 3].matrix),
				intersectionPoint))
		{
			for (i = 0; i < (int) (mMprPlaneList.size() - 1); i++)
			{
				if (mMprPlaneList[i].node)
				{
					mMprPlaneList[i].node->centerPosition.setValue(intersectionPoint);
				}
			}
		}
	}
	else
	{
		// translate all MPR planes to new mouse position (except current one)
		for (i = 0; i < (int) (mMprPlaneList.size() - 1); i++)
		{
			SbMatrix m = XipGeomUtils::translatePlaneNormal(mMprPlaneList[i].matrix, movement);

			if (mMprPlaneList[i].node)
			{
				mMprPlaneList[i].node->centerPosition.setValue(mIntersectionPosition + movement);
				mMprPlaneList[i].node->intersectMatrix.setValue(m);

				mMprPlaneList[i].center = mIntersectionPosition + movement;
			}

			if (mMprPlaneList[i].matrixField)
			{
				if (!mMprPlaneList[i].matrixField->getValue().equals(m, XIP_FLT_EPSILON))
				{
					mMprPlaneList[i].matrixField->setValue(m);
				}
			}
		}
	}
}


SbBool SoXipMprIntersectionManip::dragEnd()
{
	mPickedLine = -1;
	mPickedCenter = FALSE;

	return SoXipPlaneManipBase::dragEnd();
}


int SoXipMprIntersectionManip::getPickedLine()
{
	// Can't pick if we don't have an action, now can we?
	if (!mHandleEventAction) return -1;
	if (mMprPlaneList.size() <= 0) return -1;

	SoRayPickAction pa(mHandleEventAction->getViewportRegion());
	pa.setPoint(mHandleEventAction->getEvent()->getPosition());
	pa.setRadius(3);
	pa.setPickAll(TRUE);
	pa.enableCulling(FALSE);
	pa.apply(mHandleEventAction->getNodeAppliedTo());

	SoPickedPointList pointList = pa.getPickedPointList();
	int picked = -1;

	for (int j = 0; j < pointList.getLength(); j++)
	{
		const SoPickedPoint *picked_point = pointList[j];
		if (!picked_point) continue;

		// check for dog ear or other geometry on top of reference lines,
		// which is very close to the near plane (distance ~ 1)
		int basePlane = mMprPlaneList.size() - 1;
		SbPlane nearPlane = XipGeomUtils::planeFromMatrix(mMprPlaneList[basePlane].matrix);
		SbPlane pickPlane(nearPlane.getNormal(), picked_point->getPoint());
		float dist = fabs(nearPlane.getDistanceFromOrigin() - pickPlane.getDistanceFromOrigin());
		if ((dist > 0.95) && (dist < 1.05))
		{
			picked = -1;
			break;
		}

		const SoPath *dpath = picked_point->getPath();
		if (!dpath) return -1;

		for (int i = 0; i < (int)mMprPlaneList.size(); i++)
		{
			if (mMprPlaneList[i].node)
			{
				SoNode *node = mMprPlaneList[i].node->getPart("lineSet", FALSE);
				if (node)
				{
					if (dpath->containsNode(node))
					{
						picked = i;
					}
				}

				node = mMprPlaneList[i].node->getPart("gapLineSet", FALSE);
				if (node)
				{
					if (dpath->containsNode(node))
					{
						picked = i;
					}
				}
			}
		}
	}

	return picked;
}


SbVec3f SoXipMprIntersectionManip::projectCenterOnPlane(const SbMatrix &intersectMatrix, const SbVec3f &center)
{
	// project center point on intersection line (closest point)
	SbPlane plane = XipGeomUtils::planeFromMatrix(mMprPlaneList[mMprPlaneList.size() - 1].matrix);
	SbPlane intersectPlane = XipGeomUtils::planeFromMatrix(intersectMatrix);
	SbLine line;

	if (XipGeomUtils::planeIntersect(plane, intersectPlane, line))
	{
		return line.getClosestPoint(center);
	}

	return center;
}


void SoXipMprIntersectionManip::handleEvent(SoHandleEventAction *action)
{
	if (!action || !on.getValue()) return;
	if (mMprPlaneList.size() <= 0) return;

	SoXipPlaneManipBase::handleEvent(action);

	if (action->getEvent()->isOfType(SoLocation2Event::getClassTypeId()))
	{
		if (!action->getGrabber() &&
			!action->isHandled() &&
			!action->getEvent()->wasShiftDown() &&
			!action->getEvent()->wasCtrlDown())
		{
			int picked = getPickedLine();
			if (picked >= 0)
			{
				if (mode.getValue() == FREE)
				{
					// free mode, check if center or off-center (rotate)
					mRotatePosition = projectCenterOnPlane(mMprPlaneList[picked].matrix, mMprPlaneList[picked].center);
					mPickPosition = getMouseProjection();

					SbVec3f obj[2];
					int basePlane = mMprPlaneList.size() - 1;
					SbMatrix worldToObj = mMprPlaneList[basePlane].matrix.inverse();

					worldToObj.multVecMatrix(mPickPosition, obj[0]);
					worldToObj.multVecMatrix(mRotatePosition, obj[1]);

					if (!XipGeomUtils::isVecInObjectSpace(obj[0] - obj[1], 0.25))
					{
						SoXipCursor::setCursor(SoXipCursor::ROTATE);
					}
					else
					{
						SoXipCursor::setCursor(SoXipCursor::MOVE);
					}
				}
				else
				{
					SoXipCursor::setCursor(SoXipCursor::MOVE);
				}

				action->setHandled();
			}
		}
	}
}

