#include <xip/inventor/core/SoXipViewportBorder.h>
#include <Inventor/elements/SoViewportRegionElement.h>
#include <xip/inventor/core/SoXipActiveViewportElement.h>
#include <Inventor/actions/SoGLRenderAction.h>
#include <Inventor/events/SoMouseButtonEvent.h>
#include <Inventor/events/SoLocation2Event.h>
#include <Inventor/actions/SoHandleEventAction.h>
#include <Inventor/sensors/SoTimerSensor.h>
#include <xip/inventor/core/SoXipCursor.h>
#include <GL/gl.h>


SO_NODE_SOURCE(SoXipViewportBorder);


void SoXipViewportBorder::initClass()
{
	SO_NODE_INIT_CLASS(SoXipViewportBorder, SoNode, "Node");

	SO_ENABLE(SoGLRenderAction, SoXipActiveViewportElement);
}

SoXipViewportBorder::SoXipViewportBorder()
{
	SO_NODE_CONSTRUCTOR(SoXipViewportBorder);

	SO_NODE_ADD_FIELD(activeColor, (SbColor(0.6, 0.6, 0.6)));
	SO_NODE_ADD_FIELD(activeLineWidth, (3.f));
	SO_NODE_ADD_FIELD(activeLinePattern, (0xffff));

	SO_NODE_ADD_FIELD(inactiveColor, (SbColor(0.4, 0.4, 0.4)));
	SO_NODE_ADD_FIELD(inactiveLineWidth, (1.f));
	SO_NODE_ADD_FIELD(inactiveLinePattern, (0xffff));
}

SoXipViewportBorder::~SoXipViewportBorder()
{
}

void SoXipViewportBorder::GLRender(SoGLRenderAction * action)
{
	SbViewportRegion viewportRegion = SoViewportRegionElement::get( action->getState() );
	SbVec2s s = viewportRegion.getViewportSizePixels();

	double oldLineWidth = 1.0;
	glGetDoublev(GL_LINE_WIDTH, &oldLineWidth);

	glPushAttrib(GL_TRANSFORM_BIT | GL_ENABLE_BIT | GL_LINE_BIT | GL_CURRENT_BIT);
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_ALPHA_TEST);

	unsigned short pattern;
	float lineWidth;
	SbColor color;

	if (SoXipActiveViewportElement::get(action->getState()))
	{
		pattern = activeLinePattern.getValue();
		lineWidth = activeLineWidth.getValue();
		color = activeColor.getValue();
	}
	else
	{
		pattern = inactiveLinePattern.getValue();
		lineWidth = inactiveLineWidth.getValue();
		color = inactiveColor.getValue();
	}

	if (lineWidth <= 0) return;

	glColor3f(color[0], color[1], color[2]);
	glLineStipple(1, pattern);
	glEnable(GL_LINE_STIPPLE);

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0, s[0], 0, s[1], -1, 1);


	if (pattern == 0xffff)
	{
		// draw solid blocks
		// Note that on some graphics card GL_LINE_LOOP does not look good for thicker lines
		// (first/last corner not filled). This is why we use GL_QUADS instead.
		glBegin(GL_QUADS);

		glVertex2i(0, 0);
		glVertex2i(lineWidth, 0);
		glVertex2i(lineWidth, s[1]);
		glVertex2i(0, s[1]);

		glVertex2i(0, 0);
		glVertex2i(s[0], 0);
		glVertex2i(s[0], lineWidth);
		glVertex2i(0, lineWidth);

		glVertex2i(s[0] - lineWidth, 0);
		glVertex2i(s[0], 0);
		glVertex2i(s[0], s[1]);
		glVertex2i(s[0] - lineWidth, s[1]);

		glVertex2i(0, s[1] - lineWidth);
		glVertex2i(s[0], s[1] - lineWidth);
		glVertex2i(s[0], s[1]);
		glVertex2i(0, s[1]);

		glEnd();
	}
	else
	{
		// draw stippled line
		glLineWidth(lineWidth);
		lineWidth /= 2.f;
		
		glBegin(GL_LINES);

		glVertex2i(lineWidth, 0 + lineWidth);
		glVertex2i(s[0] - lineWidth + 1, 0 + lineWidth);

		glVertex2i(lineWidth, s[1] - lineWidth);
		glVertex2i(s[0] - lineWidth + 1, s[1] - lineWidth);

		glVertex2i(s[0] - lineWidth + 0.5, s[1] - lineWidth);
		glVertex2i(s[0] - lineWidth + 0.5, lineWidth);

		glVertex2i(lineWidth + 0.5, s[1] - lineWidth);
		glVertex2i(lineWidth + 0.5, lineWidth);

		glEnd();
	}


	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();

	glMatrixMode(GL_MODELVIEW);

	glLineWidth(oldLineWidth);

	glPopAttrib();
}

