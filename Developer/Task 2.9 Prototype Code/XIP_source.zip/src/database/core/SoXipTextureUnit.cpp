#include <xip/inventor/core/SoXipMultiTextureElement.h>
#include <xip/inventor/core/SoXipGLOWElement.h>

#include <xip/inventor/core/SoXipTextureUnit.h>

SO_NODE_SOURCE(SoXipTextureUnit);

//
//! ctor of SoXipTextureUnit.
//! 
//
SoXipTextureUnit::SoXipTextureUnit()
{
	SO_NODE_CONSTRUCTOR(SoXipTextureUnit);
	SO_NODE_ADD_FIELD(textureStage, (0));
	SO_NODE_ADD_FIELD(autoGenerate, (true));
}


//
//! destructor
//! 
//
SoXipTextureUnit::~SoXipTextureUnit()
{
}

void SoXipTextureUnit::initClass()
{
	SO_NODE_INIT_CLASS(SoXipTextureUnit, SoNode, "Node");
	SO_ENABLE(SoGLRenderAction, SoXipMultiTextureElement);
	SO_ENABLE(SoGLRenderAction, SoXipGLOWElement);
}

//
//! GLRender.
//! 
//! sets the active texture unit (via MultiTextureElement)
//
void SoXipTextureUnit::GLRender(SoGLRenderAction *action)
{
	if (autoGenerate.getValue()) {
		textureStage.setValue(SoXipMultiTextureElement::getFreeUnit(action->getState()));
	}
	SoXipMultiTextureElement::setUnit(action->getState(), textureStage.getValue());
}
