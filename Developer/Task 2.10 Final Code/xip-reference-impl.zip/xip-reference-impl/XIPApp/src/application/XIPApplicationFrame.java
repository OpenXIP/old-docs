/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package application;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JWindow;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * <font  face="Tahoma" size="2">
 * XIPApplicationFrame is undecorated JFrame, containing buttons panel included for testing purposes.<br></br>
 * @version	January 2008
 * @author Jaroslaw Krych
 * </font>
 */
public class XIPApplicationFrame extends JWindow {		
	private static final long serialVersionUID = 1L;
	public JButton btnUID = new JButton("Get UID");
	public JButton btnNOL = new JButton("Get Native Object Locators");
	public JButton btnNOD = new JButton("Get Native Object Descriptors");
	public JButton btnODir = new JButton("Get output DIR");
	public JButton btnTDir = new JButton("Get tmp DIR");
	public JButton btnNotifyOutput = new JButton("Notify output available");
	public JButton btnCompleted = new JButton("Processing completed");
	public JButton btnNotifyState = new JButton("Notify state changed");
	public JButton btnNotifyStatus = new JButton("Notify status changed");
	public JButton btnGroup1 = new JButton("Group1 data");
	public JButton btnGroup2 = new JButton("Group2 data");	
	public JPanel btnPanel = new JPanel();
	JPanel displayPanel;		
	
	public XIPApplicationFrame (){				
		displayPanel = new JPanel();
		btnPanel.setLayout(new GridLayout(1, 8));
		btnPanel.add(btnUID);
		btnPanel.add(btnNOL);
		btnPanel.add(btnNOD);
		btnPanel.add(btnODir);
		btnPanel.add(btnTDir);
		btnPanel.add(btnNotifyOutput);
		btnPanel.add(btnCompleted);
		btnPanel.add(btnNotifyState);
		btnPanel.add(btnNotifyStatus);
		btnPanel.add(btnGroup1);
		btnPanel.add(btnGroup2);		
		displayPanel.setLayout(new BorderLayout());
		//buildDisplayPanel();
				
		displayPanel.add(btnPanel, BorderLayout.SOUTH);
		add(displayPanel);				
		displayPanel.setBackground(Color.BLACK);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();	
		btnPanel.setPreferredSize(new Dimension((int) screenSize.getWidth(), 25));
		//displayPanel.setPreferredSize(new Dimension((int) screenSize.getWidth(), (int) screenSize.getHeight() - 85));
				
		//setExtendedState (JFrame.MAXIMIZED_BOTH);  
		//frame.pack();
		//setUndecorated(true);
		setVisible(true);		
	}
	
	public Dimension getAppPanelDimension(){
		return getPreferredSize();
	}
	
	public void setAppPanelDimension(Dimension size){
		setPreferredSize(size);
	}			
	
	public JPanel getDisplayPanel(){
		return displayPanel;
	}
	
	public static void main(String [] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedLookAndFeelException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
		
		XIPApplicationFrame frame = new XIPApplicationFrame();
		frame.addWindowListener(new WindowAdapter(){	         
		public void windowClosing(WindowEvent e){    	        	 	        										
			System.exit(0);
			}	         
		});
	}
	
}
