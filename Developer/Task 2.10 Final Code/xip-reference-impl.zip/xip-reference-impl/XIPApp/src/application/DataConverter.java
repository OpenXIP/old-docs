/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package application;

import java.net.URI;
import java.net.URISyntaxException;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.NativeObjectDescriptor;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.NativeObjectLocator;

public class DataConverter {
	/*public org.nema.dicom.wg23.NativeObjectDescriptor [] toNODArray(List<NativeObjectDescriptor> nativeObjectDesc){
		org.nema.dicom.wg23.NativeObjectDescriptor[] descArray = new org.nema.dicom.wg23.NativeObjectDescriptor[nativeObjectDesc.size()];
		for(int i = 0; i < nativeObjectDesc.size(); i++){
			org.nema.dicom.wg23.NativeObjectDescriptor desc = new org.nema.dicom.wg23.NativeObjectDescriptor();
			desc.setUUID(nativeObjectDesc.get(i).getUUID());
			desc.setMimeType(nativeObjectDesc.get(i).getMimeType());
			desc.setSOPClassUID(nativeObjectDesc.get(i).getSOPClassUID());
			descArray[i] = desc;			
		}				
		return descArray;
	}
	
	public org.nema.dicom.wg23.NativeObjectLocator [] toNOLArray(List<NativeObjectLocator> nativeObjectLoc){
		org.nema.dicom.wg23.NativeObjectLocator [] locArray = new org.nema.dicom.wg23.NativeObjectLocator [nativeObjectLoc.size()];
		for(int i = 0; i < nativeObjectLoc.size(); i++){
			org.nema.dicom.wg23.NativeObjectLocator loc = new org.nema.dicom.wg23.NativeObjectLocator();
			loc.setUUID(nativeObjectLoc.get(i).getUUID());
			try {
				loc.setURI(new URI(nativeObjectLoc.get(i).getURI()));
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			locArray[i] = loc;
		}
		return locArray;
	}*/
	
	public org.nema.dicom.wg23.NativeObjectDescriptor toNODArray(NativeObjectDescriptor nod){		
		org.nema.dicom.wg23.NativeObjectDescriptor desc = new org.nema.dicom.wg23.NativeObjectDescriptor();
		desc.setUUID(nod.getUUID());
		desc.setMimeType(nod.getMimeType());
		desc.setSOPClassUID(nod.getSOPClassUID());										
		return desc;
	}
	
	public org.nema.dicom.wg23.NativeObjectLocator toNOLArray(NativeObjectLocator nol){		
		org.nema.dicom.wg23.NativeObjectLocator loc = new org.nema.dicom.wg23.NativeObjectLocator();
		loc.setUUID(nol.getUUID());
		try {
			loc.setURI(new URI(nol.getURI()));
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
		return loc;
	}
}
