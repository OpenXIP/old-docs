package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.List;
import java.util.StringTokenizer;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import edu.northwestern.radiology.aim._1.AnatomicEntity;
import edu.northwestern.radiology.aim._1.Annotation;
import edu.northwestern.radiology.aim._1.Calculation;
import edu.northwestern.radiology.aim._1.CalculationResult;
import edu.northwestern.radiology.aim._1.Data;
import edu.northwestern.radiology.aim._1.GeometricShape;
import edu.northwestern.radiology.aim._1.ImageAnnotation;
import edu.northwestern.radiology.aim._1.ObjectFactory;
import edu.northwestern.radiology.aim._1.SpatialCoordinate;
import edu.northwestern.radiology.aim._1.Calculation.CalculationResultCollection;
import edu.northwestern.radiology.aim._1.CalculationResult.DataCollection;
import edu.northwestern.radiology.aim._1.GeometricShape.SpatialCoordinateCollection;

public class AimToXipConverter extends Annotation {
	BigInteger bi1 = new BigInteger("1234567890123456890");
	File xmlDocument = new File("./aimData/outAnnotation.xml");
	BasicDicomParser parser = new BasicDicomParser();
	
	public AimToXipConverter(){
		
	}
	public void Marshall(){
		try {
			JAXBContext jaxbContext=JAXBContext.newInstance("edu.northwestern.radiology.aim._1");
			Marshaller marshaller=jaxbContext.createMarshaller();
			ObjectFactory factory=new ObjectFactory(); 
			AnatomicEntity anatEnt = (AnatomicEntity)factory.createAnatomicEntity();
			anatEnt.setCodeMeaning("Some meaning");
			anatEnt.setId(bi1);
			ImageAnnotation imageAnn = new ImageAnnotation();
			imageAnn.setId(bi1);
			imageAnn.setName("ImageAnnotation1");
			imageAnn.setComment("Some comment");			
			
			
			try {
				marshaller.marshal(imageAnn, new FileOutputStream(xmlDocument));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	String label;
	float caption;
	String strCoord1;
	String strCoord2;
	public void unMarshall(File xmlFile){
		/* 1. Get list of all aim objects
		 * 2. Read each aim object
		 * 3. retrieve coordinates, other and form SoXipLineMeasurement {}
		 * 3. add other xip file pices
		 * 4. Save to the file
		 * 5. Convert coordinates
		 * 
		 */ 
		
		try {
			JAXBContext jc = JAXBContext.newInstance( "edu.northwestern.radiology.aim._1" );
			Unmarshaller u = jc.createUnmarshaller();
	        //JAXBElement fooObj = (JAXBElement)u.unmarshal( new File( "./aimData/AIMExample_ImageAnnotationAIMv1_07.xml" ) );
			JAXBElement fooObj = (JAXBElement)u.unmarshal(xmlFile);
	        //System.out.println(((ImageAnnotation)fooObj.getValue()).getName());
	        //System.out.println(((ImageAnnotation)fooObj.getValue()).getComment());			
			User user = ((ImageAnnotation)fooObj.getValue()).getUser();
			label = user.getUser().getAuthorName();
			
			CalculationCollection calcColl = ((ImageAnnotation)fooObj.getValue()).getCalculationCollection();
			List<Calculation> calcList = calcColl.getCalculation();
			for(int i = 0; i < calcList.size(); i++){
				CalculationResultCollection calcResultColl = calcList.get(i).getCalculationResultCollection();
				List<CalculationResult> calcResultList = calcResultColl.getCalculationResult();
				for(int j = 0; j < calcResultList.size(); j++){
					DataCollection dataColl = calcResultList.get(j).getDataCollection();
					/*List<Dimension> dimList = calcResultList.get(j).getDimensionCollection().getDimension();
					for(int k = 0; k < dimList.size(); k++){
						label = dimList.get(k).getLabel();
						System.out.println(label);
					}*/
					List<Data> dataList = dataColl.getData();
					for(int k = 0; k < dataList.size(); k++){
						caption = dataList.get(k).getValue();
						System.out.println(caption);
					}
				}
			}
			
			List<GeometricShape> collGeoShape = (((ImageAnnotation)fooObj.getValue()).getGeometricShapeCollection().getGeometricShape());	       
	        for (int i = 0; i < collGeoShape.size(); i++){
	        	SpatialCoordinateCollection spatialCoordColl = collGeoShape.get(i).getSpatialCoordinateCollection();
	        	List<SpatialCoordinate> spatialCoord = spatialCoordColl.getSpatialCoordinate();
	        	for(int j = 0; j < spatialCoord.size(); j++){
	        		float x = spatialCoord.get(j).getX();
	        		float y = spatialCoord.get(j).getY();
	        		float z = spatialCoord.get(j).getZ();	        		
		        	if(j == 0){
		        		strCoord1 = x + " " + y + " " + z;
		        		System.out.println(strCoord1);
		        	}else if(j == 1){
		        		strCoord2 = x + " " + y + " " + z;
		        		System.out.println(strCoord2);
		        	}	        			
	        	}
	        }
	        
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}               
	}
	
	public File[] getAIMObjects(File dir){
		File[] files = dir.listFiles();
		/*for (int i = 0; i < files.length; i++){
			System.out.println(files[i].getName());
		}*/
		return files;
	}
	
	public String getLabel(){
		return label;
	}
	public String getCaption(){
		String str = Float.toString(caption);
		return str;
	}
	public String getCoord1(){
		return strCoord1;
	}
	public String getCoord2(){
		return strCoord2;
	}
	
	public static void main(String[] args) {
		AimToXipConverter test = new AimToXipConverter();
		File outFile = new File("xipOverlayManager.txt");
		FileWriter out = null;
		try {
			out = new FileWriter(outFile);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//test.unMarshall();
		//test.Marshall();
		File [] files = test.getAIMObjects(new File("C:/WUSTL/XIP_Admin/AIM/aim_11_13_2007/AIM-Sample-Instances/Annotations/AIM-XML"));	    
		try {
			out.write("#Inventor V2.1 ascii" + "\r\n");
			out.write("\r\n");
			out.write("Separator {" + "\r\n");
			out.write("DEF +0 SoXipShapeList {" + "\r\n");
			out.write("fields [ SFString label ]" + "\r\n");
			out.write("label	\"\"" + "\r\n");
			out.write("Separator {" + "\r\n");
			out.write("Label {" + "\r\n");
			out.write("label	\"\" =" + "\r\n");
			out.write("USE +0" + "\r\n");
			out.write(" . label" + "\r\n");
			out.write("\r\n");
			out.write("}" + "\r\n");
			out.write("Separator {" + "\r\n");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		for(int i = 0; i < files.length; i++){
			test.unMarshall(files[0]);
			//test.convertCoordinates(String x, String y, String z);
            try {
            	out.write("SoXipLineMeasurement {" + "\r\n");
            	//out.write("\t" + "fields [ SFEnum status, SFInt32 rank, SFString label, SFString caption, SFVec3f textPosition, MFVec3f point ]" + "\r\n");
            	out.write("\t" + "fields [ SFEnum status, SFInt32 rank, SFString label, SFString caption, MFVec3f point ]" + "\r\n");
         		out.write("\t" + "status	CREATE" + "\r\n");
         		out.write("\t" + "rank" + "\t" + (i + 1) + "\r\n");
            	out.write("\t" + "label" + "\t" + test.getLabel() + "\r\n");
         		//out.write("\t" + "label" + "\t" + "\"\"" + "\r\n");
            	out.write("\t" + "caption" + "\t" + test.getCaption() + " mm" + "\r\n");                            
            	//out.write("\t" + "textPosition" + "\t" + "0.00 0.00 0.00" + "\r\n"); 
            	out.write("\t" + "point" + "[ " + test.getCoord1() + ", " + test.getCoord2() + " ]" + "\r\n");            	 
            	out.write("}" + "\r\n");
            }
            catch (IOException e)
            {                
                System.out.println("WRITE ERROR: " + e.toString());                
            }              
		}
		try {
			out.write("}" + "\r\n");
			out.write("}" + "\r\n");
			out.write("}" + "\r\n");
			out.write("}" + "\r\n");
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	
	public String [] convertCoordinates (String x, String y, String z){		
		String [] coord = new String[3];
		String str = parser.getImagePositionPatient();
		StringTokenizer st = new StringTokenizer(str, "\\");
		int i = 0;
		while (st.hasMoreTokens()) {
	         System.out.println(st.nextToken());
	         coord[i] = st.nextToken();
	         i++;
	     }		
		return coord;
	}

}
