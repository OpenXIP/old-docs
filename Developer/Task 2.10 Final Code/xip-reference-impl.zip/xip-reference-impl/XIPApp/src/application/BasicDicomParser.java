/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package application;

import java.io.File;
import java.io.IOException;
import com.pixelmed.dicom.AttributeList;
import com.pixelmed.dicom.DicomException;
import com.pixelmed.dicom.TagFromName;

/**
 * <font  face="Tahoma" size="2">
 * Parses DICOM file and retrieves commonly used attribues.<br></br>
 * @version	January 2008
 * @author Jaroslaw Krych
 * </font>
 */
public class BasicDicomParser {
	String strFileDir = new String();
	AttributeList list = new AttributeList();
	String strPatient = new String();
	String strStudy = new String();
	String strSeries = new String();
	String strSOPClassUID = new String();
	String strStudyDate = new String();
	String strContentDate = new String();
	String strSeriesDate = new String();
	String strStudyInstanceUID = new String();
	String strBitsStored = new String();
	String sopInstanceUID = new String();
	
	public AttributeList parseDicom(File dicomFile){
		try {			
			list.read(dicomFile.getAbsolutePath() ,null,true,true);
		} catch (IOException e) {			
			new ExceptionDialog("DICOM Exception!", 
					dicomFile.getName() + " is not DICOM file!",
					"Data for this file will not be saved.");
			//e.printStackTrace();
		} catch (DicomException e) {		
			e.printStackTrace();
		}				
		return list;
	}
    
	public String getPatient(){				
		try{
			strPatient = list.get(TagFromName.PatientName).getDelimitedStringValuesOrEmptyString();
			return strPatient;
		}catch (NullPointerException e){
			return "";
		}
	}
	
	public String getStudy(){
		try{
			strStudy = list.get(TagFromName.StudyDescription).getDelimitedStringValuesOrEmptyString();
			return strStudy;
		}catch (NullPointerException e){
			return "";
		}				
	}
	public String getStudyInstanceUID(){
		try{
			strStudyInstanceUID = list.get(TagFromName.StudyInstanceUID).getDelimitedStringValuesOrEmptyString();
			return strStudyInstanceUID;
		}catch (NullPointerException e){
			return "";
		}				
	}
	
	public String getSeries(){
		try{
			strSeries = list.get(TagFromName.SeriesInstanceUID).getDelimitedStringValuesOrEmptyString();
			return strSeries;
		}catch (NullPointerException e){
			return "";
		}
	}
	
	public String getSOPClassUID(){
		try{
			strSOPClassUID =list.get(TagFromName.SOPClassUID).getDelimitedStringValuesOrEmptyString();
			return strSOPClassUID;
		}catch (NullPointerException e){
			return "";
		}		
	}
	
	public String getStudyDate(){
		try{
			strStudyDate = list.get(TagFromName.StudyDate).getDelimitedStringValuesOrEmptyString();
			return strStudyDate;
		}catch (NullPointerException e){
			return "";
		}					
	}
	
	public String getContentDate(){
		try{
			strContentDate = list.get(TagFromName.ContentDate).getDelimitedStringValuesOrEmptyString();
			return strContentDate;
		}catch (NullPointerException e){
			return "";
		}			
	}
	
	public String getSeriesDate(){
		try{
			strSeriesDate = list.get(TagFromName.SeriesDate).getDelimitedStringValuesOrEmptyString();
			return strSeriesDate;
		}catch (NullPointerException e){
			return "";
		}		
	}
	
	public String getBitsStored(){
		try{
			strBitsStored = list.get(TagFromName.BitsStored).getDelimitedStringValuesOrEmptyString();
			return strBitsStored;
		}catch (NullPointerException e){
			return "";
		}					
	}
	
	public String getImagePositionPatient(){
		try{
			return list.get(TagFromName.ImagePositionPatient).getDelimitedStringValuesOrEmptyString();
		}catch (NullPointerException e){
			return "";
		}							
	}
	
	public void setFileDir(String fileDir){
		strFileDir = fileDir;
	}
	
	/*public AttributeList getShortAttributeList(AttributeList fullAttributeList){
		AttributeList attList = new AttributeList();
		String[] characterSets = { "ISO_IR 100" };
		SpecificCharacterSet specificCharacterSet = new SpecificCharacterSet(characterSets);
		try{
			{ AttributeTag t = TagFromName.PatientName; Attribute a = new PersonNameAttribute(t,specificCharacterSet); a.addValue(fullAttributeList.get(TagFromName.PatientName).getDelimitedStringValuesOrEmptyString()); attList.put(t,a); }
			{ AttributeTag t = TagFromName.PatientID; Attribute a = new ShortStringAttribute(t,specificCharacterSet); attList.put(t,a); }
			{ AttributeTag t = TagFromName.StudyInstanceUID; Attribute a = new UniqueIdentifierAttribute(t); attList.put(t,a); }		
			{ AttributeTag t = TagFromName.SeriesInstanceUID; Attribute a = new UniqueIdentifierAttribute(t); a.addValue(fullAttributeList.get(TagFromName.SeriesInstanceUID).getDelimitedStringValuesOrEmptyString()); attList.put(t,a); }
			{ AttributeTag t = TagFromName.SOPInstanceUID; Attribute a = new UniqueIdentifierAttribute(t); a.addValue(fullAttributeList.get(TagFromName.SOPClassUID).getDelimitedStringValuesOrEmptyString()); attList.put(t,a); }
			
		}catch (DicomException e){
			
		}
		return attList;
	}
	
	*/
		
	public String getSOPInstanceUID(){
		try{
			sopInstanceUID = list.get(TagFromName.SOPInstanceUID).getDelimitedStringValuesOrEmptyString();
			return sopInstanceUID;
		}catch (NullPointerException e){
			return "";
		}					
	}
	
	public static void main (String [] args){
		BasicDicomParser parser = new BasicDicomParser();
		parser.parseDicom(new File("E:/IHEConnectathon/3dviewer/3dviewer_demo/data/Acetabulum/ACETABULUM_1"));
		parser.getStudy();
	}
}
