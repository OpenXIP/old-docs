/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23.impl;

/**
 * @author Jaroslaw Krych
 *
 */
import java.util.EventListener;

public interface WindowFocusListener extends EventListener{
	public void toFront(WindowFocusEvent e);
}
