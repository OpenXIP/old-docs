/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23.impl;

import java.util.EventObject;

import org.nema.dicom.wg23.Application;

/**
 * @author Jaroslaw Krych
 *
 */
//Identifies the object that generates the event
public class WindowFocusEvent extends EventObject{	
	
	public WindowFocusEvent(Application source){		
		super(source);
	}
}
