/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import org.nema.dicom.wg23.impl.StateUpdateEvent;
import org.nema.dicom.wg23.impl.StateUpdateListener;
import org.nema.dicom.wg23.impl.WindowFocusEvent;
import org.nema.dicom.wg23.impl.WindowFocusListener;
import org.nema.dicom.wg23.ApplicationInterface;
import org.nema.dicom.wg23.NativeObjectDescriptor;
import org.nema.dicom.wg23.NativeObjectLocator;
import org.nema.dicom.wg23.State;
/**
 * <font  face="Tahoma" size="2">
 * Application is a class implementing WG23 interface.<br></br>
 * It is a receiving point for all requests coming from XIP Host. <br></br>
 * <br></br>
 * The following is an example how to use Application class:
 * <br></br>
 *<ul>
 * Application appInterfaceImpl = new Application(URL hostURL, URL appURL);<br></br>
 * Endpoint endpoint = Endpoint.publish(appEPR, appInterfaceImpl);<br></br>
 * appInterfaceImpl.addStateUpdateListener(this);<br></br>
 * appInterfaceImpl.setState(wg23Interface.wg23.State.IDLE);
 * </ul>
 * @version	August 2007
 * @author Jaroslaw Krych
 * </font>
 */
@WebService()
public class Application implements ApplicationInterface {	
	List<NativeObjectDescriptor> nativeObjectDesc = new ArrayList<NativeObjectDescriptor>();
	List<NativeObjectLocator> nativeObjectLoc = new ArrayList<NativeObjectLocator>();	
	
	/**
	 * Provides implementations for WG23 interface methods pertaining to the application.
	 */
	public Application(){	}
	
	/**
	 * Used to return an array of native object locators back to the host.
	 * @param nativeObjectDescriptor NativeObjectDescriptor
	 * @return Returns and array of native object locators containing URI of the output objects.
	 */
	@WebMethod()
	public NativeObjectLocator[] getAsFile(NativeObjectDescriptor[] nativeObjectDescriptor) {		
		/*
		 * If Host request NOLs after COMPLETED notofication was sent,
		 * ensure all NOLS were passed to the Host and clear the array of NOLs
		 */
		
		NativeObjectLocator[] nols = new NativeObjectLocator[nativeObjectLoc.size()];
		for(int i = 0; i < nols.length; i++){
			nols[i] = nativeObjectLoc.get(i);
		}
		return nols;
	}
	
	/**
	 * Used to return an array of native object descriptors back to the host.
	 * @return Returns and array of native object descriptors.
	 */
	@WebMethod()
	public NativeObjectDescriptor[] getNativeObjectDescriptors() {		
		NativeObjectDescriptor[] nods = new NativeObjectDescriptor[nativeObjectDesc.size()];
		for(int i = 0; i < nods.length; i++){
			nods[i] = nativeObjectDesc.get(i);
		}
		return nods;
	}
	
	/**
	 * Used to return application's current state to the host
	 * @return Returns application's state.
	 */
	@WebMethod()
	public State getState() {		
		return state;
	}
	
	/**
	 * Used to set application's state
	 * @return Returns true when state set.
	 */
	State state;
	@WebMethod()
	public Boolean setState(State state) {		
		try{			
			this.state = state;
			if(state == State.EXIT){
				Exit carryExit = new Exit();
				Thread t = new Thread(carryExit);
				t.start();				
				return new Boolean(true);
			}else{
				fireStateChanged();
				return new Boolean(true);
			}			
		}catch (Exception e){
			return new Boolean(false);
		}		
	}
	@WebMethod()
	public Boolean bringToFront() {
		fireBringToFront();
		return new Boolean(true);		
	}
	
	/**
	 * Gets application's current state in form of string
	 * @return Returns application's state.
	 */
	public String getAppCurrentState(){
		return this.state.toString();
	}	
	
	
	StateUpdateListener listener1;
	/**
	 * Adds a StateUpdateListener to the application interface implementation class.
	 * @param l the StateUpdateListener to be added 
	 */
    public void addStateUpdateListener(StateUpdateListener l) {        
        listener1 = l;                
    }
	
	private void fireStateChanged() {		
		StateUpdateEvent event = new StateUpdateEvent(this);         				
        listener1.stateChanged(event); 
	}
	public class Exit extends Thread {                      
	        public void run() {              
	        	fireStateChanged();
	        }
	}
	
	WindowFocusListener listener2;
	public void addWindowFocusListener(WindowFocusListener l){
		listener2 = l;
	}
	private void fireBringToFront(){
		WindowFocusEvent event = new WindowFocusEvent(this);
		listener2.toFront(event);
	}
	
	
	/* NODs and NOLs are set by application.
	 * Host requests them after notifyOutputAvailable() or setState(State.COMPLETED) */
	/**
	 * Method used by XIP application to set native object descriptors<br></br>
	 * on the application's interface implementation class (ApplicationInterfaceImpl).
	 */
	/*public void setNativeObjectDescriptor(NativeObjectDescriptor[] nods){						
		for(int i = 0; i < nods.length; i++){
			this.nativeObjectDesc.add(nods[i]);
		}		
	}*/
	public void setNativeObjectDescriptor(NativeObjectDescriptor nod){
		this.nativeObjectDesc.add(nod);
	}
	/**
	 * Method used by XIP application to set native object locators<br></br>
	 * on the application's interface implementation class (ApplicationInterfaceImpl).
	 */
	public void setNativeObjectLocator (NativeObjectLocator[] nols){
		for(int i = 0; i < nols.length; i++){
			this.nativeObjectLoc.add(nols[i]);
		}
		
	}
	public void setNativeObjectLocator (NativeObjectLocator nol){
		this.nativeObjectLoc.add(nol);
	}
	
}

