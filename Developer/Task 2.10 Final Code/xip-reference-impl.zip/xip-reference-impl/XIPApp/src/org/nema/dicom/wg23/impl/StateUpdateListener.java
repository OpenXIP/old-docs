/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23.impl;

import java.util.EventListener;

public interface StateUpdateListener extends EventListener{
	public void stateChanged(StateUpdateEvent e);
}
