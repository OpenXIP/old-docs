/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23.impl;

import java.util.EventObject;
import org.nema.dicom.wg23.Application;

//Identifies the object that generates the event
public class StateUpdateEvent extends EventObject{	
	
	public StateUpdateEvent(Application source){		
		super(source);
	}
}
