/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import application.BasicDicomParser;
import application.DataConverter;
import application.ExceptionDialog;
import application.Util;
import application.XIPApplication;
import application.XIPApplicationFrame;
import application.XIPApplicationFrameTempl;

import org.nema.dicom.wg23.clientToHost.clientArtifacts.NativeObjectDescriptor;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.NativeObjectLocator;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.Rectangle;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.State;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.Status;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.StatusType;
import org.nema.dicom.wg23.Application;
import org.nema.dicom.wg23.impl.StateUpdateEvent;
import org.nema.dicom.wg23.impl.StateUpdateListener;
import org.nema.dicom.wg23.impl.WindowFocusEvent;
import org.nema.dicom.wg23.impl.WindowFocusListener;

public class RECISTFollowUpAdjudicator extends XIPApplication implements StateUpdateListener, WindowFocusListener{
	XIPApplicationFrameTempl frame = new XIPApplicationFrameTempl();
	RECISTFollowUpAdjudicatorPanel appPanel = new RECISTFollowUpAdjudicatorPanel();		
	DataConverter converter = new DataConverter();
	
	String outDir;
	State appCurrentState;	
	
	public RECISTFollowUpAdjudicator(URL hostURL, URL appURL) {
		super(hostURL, appURL);		
		frame.getDisplayPanel().add(appPanel);
		frame.setVisible(true);	
		getApplicationInterfaceImpl().addStateUpdateListener(this);
		getApplicationInterfaceImpl().addWindowFocusListener(this);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			System.out.println("Number of parameters: " + args.length);
			for (int i = 0; i < args.length; i++){
				System.out.println(i + ". " + args[i]);
			}
			URL hostURL = null;
			URL applicationURL = null;
			for (int i = 0; i < args.length; i++){
				if (args[i].equalsIgnoreCase("-hostURL")){
					hostURL = new URL(args[i + 1]);
				}else if(args[i].equalsIgnoreCase("-applicationURL")){
					applicationURL = new URL(args[i + 1]);
				}					
			}			
			//final XIPApplication_WashU app = new XIPApplication_WashU(new URL(args[0]), new URL(args[1]));			
			final RECISTFollowUpAdjudicator app = new RECISTFollowUpAdjudicator(hostURL, applicationURL);						
			app.frame.setFocusableWindowState(true);
			app.frame.addWindowListener(new WindowAdapter(){	         
				public void windowClosing(WindowEvent e){    	        	 	        	
					/* Notify Host when application is terminated */
					app.getClientToHost().notifyStateChanged(State.EXIT);
					app.getEndPoint().stop();
					System.exit(0);
		         }
				
			});			
			/*Set application dimensions */
			Rectangle rect = app.getClientToHost().getAvailableScreen(null);			
			app.frame.setBounds(rect.getRefPointX(), rect.getRefPointY(), rect.getScreenWidth(), rect.getScreenHeight());
			/*Notify Host application was launched*/
			//app.getApplicationInterfaceImpl().setState(org.nema.dicom.wg23.State.IDLE);
			app.getClientToHost().notifyStateChanged(State.IDLE);			
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedLookAndFeelException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MalformedURLException e) {			
			e.printStackTrace();
		} catch (NullPointerException e){
			new ExceptionDialog("List of parameters is not valid!", 
					"Ensure: -hostURL url1 -applicationURL url2",
					"Launch Application Dialog");
			System.exit(0);
		}
	}

	List<NativeObjectDescriptor> nativeObjectDesc;
	List<NativeObjectLocator> nativeObjectLoc;	
	public void stateChanged(StateUpdateEvent e) {				
		//System.out.println("Application's current state: " + ((ApplicationInterfaceImpl)e.getSource()).getAppCurrentState());
		if(e.getSource() == this.getApplicationInterfaceImpl()){
			String strState = ((Application)e.getSource()).getAppCurrentState();			
			/*
			 * Handle different states
			 */
			//State state = State.fromValue(strState);
			//System.out.println("Application's current state: " + state);						
			if (strState == State.IDLE.toString()){
				this.getClientToHost().notifyStateChanged(State.IDLE);				
			}else if(strState == State.INPROGRESS.toString()){				
				this.getClientToHost().notifyStateChanged(State.INPROGRESS);
				
				/*
				 * The following is valid when prior state is IDLE (not SUSPENDED)
				 * 1. Application requests Native Object Descriptors from the Host
				 * 2. Application evaluates Native Object Descriptors (to determine which MIME type it can support)
				 * 3. Application selects all objects or subset of objects for which it is going to request Native Object Locators
				 * 4. Application reuests Native Object Locators (NOLs)
				 * 5. Application gets data (pixel data) based on provided NOLs
				 * 6. Application starts processing data or waits for end-user instractions
				 *  
				 */
				
				// The same as NOD
				nativeObjectDesc = this.getClientToHost().getNativeObjectDescriptors();								
				nativeObjectLoc = this.getClientToHost().getAsFile(nativeObjectDesc);
							
				//arrangeData makes two groups DICOM and AIM
				arrangeData(nativeObjectDesc);
				arrangeDicomDataSet(getNOLsGroupDicom());								
				arrangeAimDataSet(nolsGroupAim);
				//System.out.println("Group1:");
				//System.out.println(getSceneGraphInputPrevious());
				//System.out.println("Group2:");
				//System.out.println(getSceneGraphInputCurrent());
				
				
				
				appPanel.getIvCanvas().set("LoadDicom1.name", getSceneGraphInputPrevious());					  
				appPanel.getIvCanvas().set("LoadDicom2.name", getSceneGraphInputCurrent());
				appPanel.getIvCanvas().set("DicomExaminer1.imageIndex", "2");
				appPanel.getIvCanvas().set("DicomExaminer2.imageIndex", "2");
				appPanel.getIvCanvas().set("SelectMode1.index", "2");
				appPanel.getIvCanvas().set("SelectMode2.index", "0");
				appPanel.getIvCanvas().set("OverlayManager2.create", "1");
				appPanel.getIvCanvas().set("OverlayManager2.menuEnabled", "1");
				appPanel.getIvCanvas().set("LockModeToggle.toggle", "");
				appPanel.getIvCanvas().set("LockModeToggle.on", "");
				appPanel.getIvCanvas().set("DicomExaminer1.viewAll", "");				
				appPanel.getIvCanvas().set("DicomExaminer2.viewAll", "");
				//appPanel.getIvCanvas().processQueue();

				
				/*
				 * At this point data is processed
				 * When done notifyOutputAvailable or setState(COMLETED)
				 */								
				
				//Case 2:
			}else if(strState == State.SUSPENDED.toString()){
				System.out.println("Suspend was requested");
			}else if(strState == State.CANCELED.toString()){				
				appCurrentState = State.CANCELED;
				this.getClientToHost().notifyStateChanged(State.CANCELED);
				/*
				 * 1. Stop processing: automatic processing
				 * 2. Stop IO: close application's connections to the servers or databases, other
				 * 3. Clear lost of NOLs and NODs
				 * 4. Update GUI
				 * 5. After canceled completed set state to IDLe and notify host about state IDLE
				 */
				this.getClientToHost().getAsFile(this.getClientToHost().getNativeObjectDescriptors()).clear();
				this.getClientToHost().getNativeObjectDescriptors().clear();					
				appCurrentState = State.IDLE;
				this.getClientToHost().notifyStateChanged(State.IDLE);	
			}else if(strState == State.EXIT.toString()){
				System.exit(0);
			}
			
		}					
	}

	public void toFront(WindowFocusEvent e) {		
		//this.frame.toFront();
		frame.setAlwaysOnTop(true);
		frame.setAlwaysOnTop(false);
	}
	
	
	//1. Sort by StudyInstanceUID first
	//2. getData one data from each group and compare
	
	public List<NativeObjectLocator> getDataPrevious(){		
		/*int size = NOLs.size();
		int sizeSingleGroup = size/2;
		List<NativeObjectLocator> nativeObjectLocPrevious = new ArrayList<NativeObjectLocator>();
		for(int i = 0; i < sizeSingleGroup; i++){
			nativeObjectLocPrevious.add(NOLs.get(i));
		}
		return nativeObjectLocPrevious;*/
		//original NOLs list woul be unchanged, not arranged
		//arrangeDicomDataSet(getNOLsGroupDicom());
		return nolsGroup1List;
	}
	
	public String getSceneGraphInput(List<NativeObjectLocator> nols){
		String input = new String();
		int size = nols.size();
		for (int i = 0; i < size; i++){
			if(i == 0){
				String filePath;				
				filePath = new File(nols.get(i).getURI()).getPath();
				// input = input + "\"" + nols.get(i).getURI() + "\"" + ", ";					
				filePath = filePath.substring(6 , filePath.length());
				input = "[" + "\"" + filePath + "\"" + ", ";								
			} else if(i < size -1){
				String filePath = new File(nols.get(i).getURI()).getPath();
				//input = input + "\"" + nols.get(i).getURI() + "\"" + ", ";
				filePath = filePath.substring(6 , filePath.length());
				input = input + "\"" + filePath + "\"" + ", ";
			}else if(i == size -1){
				String filePath = new File(nols.get(i).getURI()).getPath();
				//input = input + "\"" + nols.get(i).getURI() + "\"" + ", ";
				filePath = filePath.substring(6 , filePath.length());
				input = input + "\"" + filePath + "\"" + "]";
			}				
		}
		return input;
	}
	
	public String getSceneGraphInputPrevious(){
		return getSceneGraphInput(nolsGroup1List);
	}
	public String getSceneGraphInputCurrent(){
		return getSceneGraphInput(nolsGroup2List);
	}
	
	public List<NativeObjectLocator> getDataCurrent(){		
		/*int size = NOLs.size();
		int sizeSingleGroup = size/2;
		List<NativeObjectLocator> nativeObjectLocCurrent = new ArrayList<NativeObjectLocator>();
		for(int i = sizeSingleGroup; i < size; i++){
			nativeObjectLocCurrent.add(NOLs.get(i));
		}
		return nativeObjectLocCurrent;*/
		//original NOLs list woul be unchanged, not arranged
		arrangeDicomDataSet(getNOLsGroupDicom());
		return nolsGroup2List;
	}
		
	
	BasicDicomParser dicomParser = new BasicDicomParser();
	List<NativeObjectLocator> nolsGroup1List;
	List<NativeObjectLocator> nolsGroup2List;
	List<String> sopInstanceUIDGroup1;
	List<String> sopInstanceUIDGroup2;
	public List<NativeObjectLocator> arrangeDicomDataSet(List<NativeObjectLocator> NOLs){				
		List<NativeObjectLocator> nolsAll = NOLs;
		List<NativeObjectLocator> nolsGroup1 = new ArrayList<NativeObjectLocator>();
		List<NativeObjectLocator> nolsGroup2 = new ArrayList<NativeObjectLocator>();
		sopInstanceUIDGroup1 = new ArrayList<String>();
		sopInstanceUIDGroup2 = new ArrayList<String>();
		String compareValue = null;
		String dateGroup1 = null;
		String dateGroup2 = null;
		for(int i = 0; i < nolsAll.size(); i++){												
			try {
				dicomParser.parseDicom(new File(new URI(nolsAll.get(i).getURI())));
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			String strStudyInstanceUID = dicomParser.getStudyInstanceUID();
			String strSOPInstanceUID = dicomParser.getSOPInstanceUID();
			if(i == 0){
				compareValue = strStudyInstanceUID;
			}			
			//System.out.println("1- " + compareValue);
			//System.out.println("2- " + strStudyInstanceUID);
			
			if(nolsGroup1.size() == 0 && nolsGroup2.size() == 0){
				nolsGroup1.add(nolsAll.get(i));
				sopInstanceUIDGroup1.add(strSOPInstanceUID);
				dateGroup1 = dicomParser.getStudyDate();
			}else{
				if(strStudyInstanceUID.compareTo(compareValue) == 0){
					nolsGroup1.add(nolsAll.get(i));
					sopInstanceUIDGroup1.add(strSOPInstanceUID);
				}else{
					nolsGroup2.add(nolsAll.get(i));
					sopInstanceUIDGroup2.add(strSOPInstanceUID);
					if(dateGroup2 == null){
						dateGroup2 = dicomParser.getStudyDate();
					}
				}
			}
		}
		
		//1. Compare dates
		//2. Overide nativeObjectLoc				
		//System.out.println("Date Group1: " + dateGroup1);
		//System.out.println("Date Group2: " + dateGroup2);
		DateFormat formatter = new SimpleDateFormat("MM/dd/yy");		
		Date date1 = null;
		Date date2 = null;
		try{					
	        String strYearG1 = dateGroup1.trim().substring(0, 4);
			String strMonthG1 = dateGroup1.trim().substring(4, 6);
			String strDayG1 = dateGroup1.trim().substring(6, 8);
	
			String strYearG2 = dateGroup2.trim().substring(0, 4);
			String strMonthG2 = dateGroup2.trim().substring(4, 6);
			String strDayG2 = dateGroup2.trim().substring(6, 8);
			date1 = (Date)formatter.parse(strMonthG1 + "/" + strDayG1 + "/" + strYearG1);
			date2 = (Date)formatter.parse(strMonthG2 + "/" + strDayG2 + "/" + strYearG2);	
		} catch(NullPointerException e){
			new ExceptionDialog("Data cannot be grouped!", 
					"Items may have the same date or more than two different dates.",
					"Scene graph input");			
			return null;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 				
		
		if(date1.before(date2)){			
			nolsGroup1List = nolsGroup1;
			nolsGroup2List = nolsGroup2;
			
		} else{
			nolsGroup1List = nolsGroup2;
			nolsGroup2List = nolsGroup1;
		}		
		int size = nolsGroup1List.size() + nolsGroup2List.size();
		List<NativeObjectLocator> arrangedNOLs = new ArrayList<NativeObjectLocator>();
		for(int i = 0; i < size; i++){
			if(i < nolsGroup1List.size()){
				arrangedNOLs.add(nolsGroup1List.get(i));
			}else{
				int j = 0;
				arrangedNOLs.add(nolsGroup2List.get(j));
				j++;
			}
			
		}		
		return arrangedNOLs;
	}
	
	List<NativeObjectLocator> nolsGroupDicom;
	List<NativeObjectLocator> nolsGroupAim;
	public void arrangeData(List<NativeObjectDescriptor> NODs){
		nolsGroupDicom = new ArrayList<NativeObjectLocator>();
		nolsGroupAim = new ArrayList<NativeObjectLocator>();
		for(int i = 0; i < NODs.size(); i++){
			String mimeType = NODs.get(i).getMimeType();
			if(mimeType.equalsIgnoreCase("application/dicom")){
				nolsGroupDicom.add(nativeObjectLoc.get(i));
			}else if(mimeType.equalsIgnoreCase("text/xml")){
				nolsGroupAim.add(nativeObjectLoc.get(i));
			}
		}
		/*System.out.println(nolsGroupDicom.size());
		System.out.println(nolsGroupAim.size());
		for (int i = 0; i < nolsGroupDicom.size(); i++){
			System.out.println(nolsGroupDicom.get(i).getURI());
		}
		for (int i = 0; i < nolsGroupAim.size(); i++){
			System.out.println(nolsGroupAim.get(i).getURI());
		}	*/
		//arrangeDicomDataSet(nolsGroupDicom);
	}
	
	public List<NativeObjectLocator> getNOLsGroupDicom(){		
		return nolsGroupDicom;
	}
	
	public void arrangeAimDataSet(List<NativeObjectLocator> nolsGroupAim){
		
	}
}
