/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import application.DataConverter;
import application.ExceptionDialog;
import application.XIPApplication;
import application.XIPApplicationFrameTempl;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.NativeObjectDescriptor;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.NativeObjectLocator;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.Rectangle;
import org.nema.dicom.wg23.clientToHost.clientArtifacts.State;
import org.nema.dicom.wg23.Application;
import org.nema.dicom.wg23.impl.StateUpdateEvent;
import org.nema.dicom.wg23.impl.StateUpdateListener;
import org.nema.dicom.wg23.impl.WindowFocusEvent;
import org.nema.dicom.wg23.impl.WindowFocusListener;

public class SiemensConeDemo extends XIPApplication implements StateUpdateListener, WindowFocusListener{
	XIPApplicationFrameTempl frame = new XIPApplicationFrameTempl();	
	DataConverter converter = new DataConverter();	
	String outDir;
	State appCurrentState;
	
	//Replace with actual application
	MainFrameCone appPanel = new MainFrameCone();
	
	public SiemensConeDemo(URL hostURL, URL appURL) {
		super(hostURL, appURL);		
		//frame.setTitle("Reference Implementation - Washington University in Saint Louis");		
		frame.getDisplayPanel().add(appPanel);
		frame.setVisible(true);		
		getApplicationInterfaceImpl().addStateUpdateListener(this);
		getApplicationInterfaceImpl().addWindowFocusListener(this);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			System.out.println("Number of parameters: " + args.length);
			for (int i = 0; i < args.length; i++){
				System.out.println(i + ". " + args[i]);
			}
			URL hostURL = null;
			URL applicationURL = null;
			for (int i = 0; i < args.length; i++){
				if (args[i].equalsIgnoreCase("-hostURL")){
					hostURL = new URL(args[i + 1]);
				}else if(args[i].equalsIgnoreCase("-applicationURL")){
					applicationURL = new URL(args[i + 1]);
				}					
			}			
			//final XIPApplication_WashU app = new XIPApplication_WashU(new URL(args[0]), new URL(args[1]));			
			final SiemensConeDemo app = new SiemensConeDemo(hostURL, applicationURL);						
			app.frame.setFocusableWindowState(true);
			app.frame.addWindowListener(new WindowAdapter(){	         
				public void windowClosing(WindowEvent e){    	        	 	        	
					/* Notify Host when application is terminated */
					app.getClientToHost().notifyStateChanged(State.EXIT);
					app.getEndPoint().stop();
					System.exit(0);
		         }
				
			});			
			/*Set application dimensions */
			Rectangle rect = app.getClientToHost().getAvailableScreen(null);			
			app.frame.setBounds(rect.getRefPointX(), rect.getRefPointY(), rect.getScreenWidth(), rect.getScreenHeight());
			/*Notify Host application was launched*/
			//app.getApplicationInterfaceImpl().setState(org.nema.dicom.wg23.State.IDLE);
			app.getClientToHost().notifyStateChanged(State.IDLE);				
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedLookAndFeelException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MalformedURLException e) {			
			e.printStackTrace();
		} catch (NullPointerException e){
			new ExceptionDialog("List of parameters is not valid!", 
					"Ensure: -hostURL url1 -applicationURL url2",
					"Launch Application Dialog");
			System.exit(0);
		}
	}

	List<NativeObjectDescriptor> nativeObjectDesc;
	List<NativeObjectLocator> nativeObjectLoc;	
	public void stateChanged(StateUpdateEvent e) {				
		//System.out.println("Application's current state: " + ((ApplicationInterfaceImpl)e.getSource()).getAppCurrentState());
		if(e.getSource() == this.getApplicationInterfaceImpl()){
			String strState = ((Application)e.getSource()).getAppCurrentState();			
			/*
			 * Handle different states
			 */
			//State state = State.fromValue(strState);
			//System.out.println("Application's current state: " + state);						
			if (strState == State.IDLE.toString()){
				this.getClientToHost().notifyStateChanged(State.IDLE);				
			}else if(strState == State.INPROGRESS.toString()){				
				this.getClientToHost().notifyStateChanged(State.INPROGRESS);
				
				/*
				 * The following is valid when prior state is IDLE (not SUSPENDED)
				 * 1. Application requests Native Object Descriptors from the Host
				 * 2. Application evaluates Native Object Descriptors (to determine which MIME type it can support)
				 * 3. Application selects all objects or subset of objects for which it is going to request Native Object Locators
				 * 4. Application reuests Native Object Locators (NOLs)
				 * 5. Application gets data (pixel data) based on provided NOLs
				 * 6. Application starts processing data or waits for end-user instractions
				 *  
				 */
				
				//The same as NOD
				nativeObjectDesc = this.getClientToHost().getNativeObjectDescriptors();												
				nativeObjectLoc = this.getClientToHost().getAsFile(nativeObjectDesc);
												
			}else if(strState == State.SUSPENDED.toString()){
				
			}else if(strState == State.CANCELED.toString()){				
				appCurrentState = State.CANCELED;
				this.getClientToHost().notifyStateChanged(State.CANCELED);
				/*
				 * 1. Stop processing: automatic processing
				 * 2. Stop IO: close application's connections to the servers or databases, other
				 * 3. Clear lost of NOLs and NODs
				 * 4. Update GUI
				 * 5. After canceled completed set state to IDLe and notify host about state IDLE
				 */
				this.getClientToHost().getAsFile(this.getClientToHost().getNativeObjectDescriptors()).clear();
				this.getClientToHost().getNativeObjectDescriptors().clear();					
				appCurrentState = State.IDLE;
				this.getClientToHost().notifyStateChanged(State.IDLE);	
			}else if(strState == State.EXIT.toString()){
				System.exit(0);
			}			
		}					
	}

	public void toFront(WindowFocusEvent e) {		
		//this.frame.toFront();
		frame.setAlwaysOnTop(true);
		frame.setAlwaysOnTop(false);
	}	
}
