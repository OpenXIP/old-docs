
package org.nema.dicom.wg23.clientToHost.clientArtifacts;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.nema.dicom.wg23.clientToHost.clientArtifacts package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GenerateUIDResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "generateUIDResponse");
    private final static QName _GetAvailableScreen_QNAME = new QName("http://wg23.dicom.nema.org/", "getAvailableScreen");
    private final static QName _GetNativeObjectDescriptorsResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "getNativeObjectDescriptorsResponse");
    private final static QName _GetAsFileResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "getAsFileResponse");
    private final static QName _GetOutputDir_QNAME = new QName("http://wg23.dicom.nema.org/", "getOutputDir");
    private final static QName _GetAvailableScreenResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "getAvailableScreenResponse");
    private final static QName _NotifyStateChanged_QNAME = new QName("http://wg23.dicom.nema.org/", "notifyStateChanged");
    private final static QName _NotifyStatus_QNAME = new QName("http://wg23.dicom.nema.org/", "notifyStatus");
    private final static QName _NotifyStatusResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "notifyStatusResponse");
    private final static QName _NotifyStateChangedResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "notifyStateChangedResponse");
    private final static QName _GetAsFile_QNAME = new QName("http://wg23.dicom.nema.org/", "getAsFile");
    private final static QName _GetTmpDirResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "getTmpDirResponse");
    private final static QName _NotifyOutputAvailableResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "notifyOutputAvailableResponse");
    private final static QName _GenerateUID_QNAME = new QName("http://wg23.dicom.nema.org/", "generateUID");
    private final static QName _GetTmpDir_QNAME = new QName("http://wg23.dicom.nema.org/", "getTmpDir");
    private final static QName _GetNativeObjectDescriptors_QNAME = new QName("http://wg23.dicom.nema.org/", "getNativeObjectDescriptors");
    private final static QName _GetOutputDirResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "getOutputDirResponse");
    private final static QName _NotifyOutputAvailable_QNAME = new QName("http://wg23.dicom.nema.org/", "notifyOutputAvailable");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.nema.dicom.wg23.clientToHost.clientArtifacts
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetTmpDir }
     * 
     */
    public GetTmpDir createGetTmpDir() {
        return new GetTmpDir();
    }

    /**
     * Create an instance of {@link GetOutputDirResponse }
     * 
     */
    public GetOutputDirResponse createGetOutputDirResponse() {
        return new GetOutputDirResponse();
    }

    /**
     * Create an instance of {@link GetNativeObjectDescriptorsResponse }
     * 
     */
    public GetNativeObjectDescriptorsResponse createGetNativeObjectDescriptorsResponse() {
        return new GetNativeObjectDescriptorsResponse();
    }

    /**
     * Create an instance of {@link GetNativeObjectDescriptors }
     * 
     */
    public GetNativeObjectDescriptors createGetNativeObjectDescriptors() {
        return new GetNativeObjectDescriptors();
    }

    /**
     * Create an instance of {@link NotifyStatus }
     * 
     */
    public NotifyStatus createNotifyStatus() {
        return new NotifyStatus();
    }

    /**
     * Create an instance of {@link GetAsFile }
     * 
     */
    public GetAsFile createGetAsFile() {
        return new GetAsFile();
    }

    /**
     * Create an instance of {@link GetTmpDirResponse }
     * 
     */
    public GetTmpDirResponse createGetTmpDirResponse() {
        return new GetTmpDirResponse();
    }

    /**
     * Create an instance of {@link NativeObjectLocator }
     * 
     */
    public NativeObjectLocator createNativeObjectLocator() {
        return new NativeObjectLocator();
    }

    /**
     * Create an instance of {@link Rectangle }
     * 
     */
    public Rectangle createRectangle() {
        return new Rectangle();
    }

    /**
     * Create an instance of {@link NativeObjectDescriptor }
     * 
     */
    public NativeObjectDescriptor createNativeObjectDescriptor() {
        return new NativeObjectDescriptor();
    }

    /**
     * Create an instance of {@link NotifyStateChanged }
     * 
     */
    public NotifyStateChanged createNotifyStateChanged() {
        return new NotifyStateChanged();
    }

    /**
     * Create an instance of {@link NotifyStateChangedResponse }
     * 
     */
    public NotifyStateChangedResponse createNotifyStateChangedResponse() {
        return new NotifyStateChangedResponse();
    }

    /**
     * Create an instance of {@link NotifyOutputAvailable }
     * 
     */
    public NotifyOutputAvailable createNotifyOutputAvailable() {
        return new NotifyOutputAvailable();
    }

    /**
     * Create an instance of {@link GetAvailableScreenResponse }
     * 
     */
    public GetAvailableScreenResponse createGetAvailableScreenResponse() {
        return new GetAvailableScreenResponse();
    }

    /**
     * Create an instance of {@link GetOutputDir }
     * 
     */
    public GetOutputDir createGetOutputDir() {
        return new GetOutputDir();
    }

    /**
     * Create an instance of {@link GenerateUIDResponse }
     * 
     */
    public GenerateUIDResponse createGenerateUIDResponse() {
        return new GenerateUIDResponse();
    }

    /**
     * Create an instance of {@link Status }
     * 
     */
    public Status createStatus() {
        return new Status();
    }

    /**
     * Create an instance of {@link GetAsFileResponse }
     * 
     */
    public GetAsFileResponse createGetAsFileResponse() {
        return new GetAsFileResponse();
    }

    /**
     * Create an instance of {@link NotifyOutputAvailableResponse }
     * 
     */
    public NotifyOutputAvailableResponse createNotifyOutputAvailableResponse() {
        return new NotifyOutputAvailableResponse();
    }

    /**
     * Create an instance of {@link GetAvailableScreen }
     * 
     */
    public GetAvailableScreen createGetAvailableScreen() {
        return new GetAvailableScreen();
    }

    /**
     * Create an instance of {@link NotifyStatusResponse }
     * 
     */
    public NotifyStatusResponse createNotifyStatusResponse() {
        return new NotifyStatusResponse();
    }

    /**
     * Create an instance of {@link GenerateUID }
     * 
     */
    public GenerateUID createGenerateUID() {
        return new GenerateUID();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GenerateUIDResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "generateUIDResponse")
    public JAXBElement<GenerateUIDResponse> createGenerateUIDResponse(GenerateUIDResponse value) {
        return new JAXBElement<GenerateUIDResponse>(_GenerateUIDResponse_QNAME, GenerateUIDResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAvailableScreen }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getAvailableScreen")
    public JAXBElement<GetAvailableScreen> createGetAvailableScreen(GetAvailableScreen value) {
        return new JAXBElement<GetAvailableScreen>(_GetAvailableScreen_QNAME, GetAvailableScreen.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetNativeObjectDescriptorsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getNativeObjectDescriptorsResponse")
    public JAXBElement<GetNativeObjectDescriptorsResponse> createGetNativeObjectDescriptorsResponse(GetNativeObjectDescriptorsResponse value) {
        return new JAXBElement<GetNativeObjectDescriptorsResponse>(_GetNativeObjectDescriptorsResponse_QNAME, GetNativeObjectDescriptorsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAsFileResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getAsFileResponse")
    public JAXBElement<GetAsFileResponse> createGetAsFileResponse(GetAsFileResponse value) {
        return new JAXBElement<GetAsFileResponse>(_GetAsFileResponse_QNAME, GetAsFileResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetOutputDir }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getOutputDir")
    public JAXBElement<GetOutputDir> createGetOutputDir(GetOutputDir value) {
        return new JAXBElement<GetOutputDir>(_GetOutputDir_QNAME, GetOutputDir.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAvailableScreenResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getAvailableScreenResponse")
    public JAXBElement<GetAvailableScreenResponse> createGetAvailableScreenResponse(GetAvailableScreenResponse value) {
        return new JAXBElement<GetAvailableScreenResponse>(_GetAvailableScreenResponse_QNAME, GetAvailableScreenResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotifyStateChanged }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "notifyStateChanged")
    public JAXBElement<NotifyStateChanged> createNotifyStateChanged(NotifyStateChanged value) {
        return new JAXBElement<NotifyStateChanged>(_NotifyStateChanged_QNAME, NotifyStateChanged.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotifyStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "notifyStatus")
    public JAXBElement<NotifyStatus> createNotifyStatus(NotifyStatus value) {
        return new JAXBElement<NotifyStatus>(_NotifyStatus_QNAME, NotifyStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotifyStatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "notifyStatusResponse")
    public JAXBElement<NotifyStatusResponse> createNotifyStatusResponse(NotifyStatusResponse value) {
        return new JAXBElement<NotifyStatusResponse>(_NotifyStatusResponse_QNAME, NotifyStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotifyStateChangedResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "notifyStateChangedResponse")
    public JAXBElement<NotifyStateChangedResponse> createNotifyStateChangedResponse(NotifyStateChangedResponse value) {
        return new JAXBElement<NotifyStateChangedResponse>(_NotifyStateChangedResponse_QNAME, NotifyStateChangedResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAsFile }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getAsFile")
    public JAXBElement<GetAsFile> createGetAsFile(GetAsFile value) {
        return new JAXBElement<GetAsFile>(_GetAsFile_QNAME, GetAsFile.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTmpDirResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getTmpDirResponse")
    public JAXBElement<GetTmpDirResponse> createGetTmpDirResponse(GetTmpDirResponse value) {
        return new JAXBElement<GetTmpDirResponse>(_GetTmpDirResponse_QNAME, GetTmpDirResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotifyOutputAvailableResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "notifyOutputAvailableResponse")
    public JAXBElement<NotifyOutputAvailableResponse> createNotifyOutputAvailableResponse(NotifyOutputAvailableResponse value) {
        return new JAXBElement<NotifyOutputAvailableResponse>(_NotifyOutputAvailableResponse_QNAME, NotifyOutputAvailableResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GenerateUID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "generateUID")
    public JAXBElement<GenerateUID> createGenerateUID(GenerateUID value) {
        return new JAXBElement<GenerateUID>(_GenerateUID_QNAME, GenerateUID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTmpDir }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getTmpDir")
    public JAXBElement<GetTmpDir> createGetTmpDir(GetTmpDir value) {
        return new JAXBElement<GetTmpDir>(_GetTmpDir_QNAME, GetTmpDir.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetNativeObjectDescriptors }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getNativeObjectDescriptors")
    public JAXBElement<GetNativeObjectDescriptors> createGetNativeObjectDescriptors(GetNativeObjectDescriptors value) {
        return new JAXBElement<GetNativeObjectDescriptors>(_GetNativeObjectDescriptors_QNAME, GetNativeObjectDescriptors.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetOutputDirResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getOutputDirResponse")
    public JAXBElement<GetOutputDirResponse> createGetOutputDirResponse(GetOutputDirResponse value) {
        return new JAXBElement<GetOutputDirResponse>(_GetOutputDirResponse_QNAME, GetOutputDirResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotifyOutputAvailable }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "notifyOutputAvailable")
    public JAXBElement<NotifyOutputAvailable> createNotifyOutputAvailable(NotifyOutputAvailable value) {
        return new JAXBElement<NotifyOutputAvailable>(_NotifyOutputAvailable_QNAME, NotifyOutputAvailable.class, null, value);
    }

}
