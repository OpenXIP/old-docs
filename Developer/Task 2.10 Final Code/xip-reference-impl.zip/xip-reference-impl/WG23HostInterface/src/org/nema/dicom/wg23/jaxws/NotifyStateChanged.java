
package org.nema.dicom.wg23.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.nema.dicom.wg23.State;

@XmlRootElement(name = "notifyStateChanged", namespace = "http://wg23.dicom.nema.org/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "notifyStateChanged", namespace = "http://wg23.dicom.nema.org/")
public class NotifyStateChanged {

    @XmlElement(name = "arg0", namespace = "")
    private State arg0;

    /**
     * 
     * @return
     *     returns State
     */
    public State getArg0() {
        return this.arg0;
    }

    /**
     * 
     * @param arg0
     *     the value for the arg0 property
     */
    public void setArg0(State arg0) {
        this.arg0 = arg0;
    }

}
