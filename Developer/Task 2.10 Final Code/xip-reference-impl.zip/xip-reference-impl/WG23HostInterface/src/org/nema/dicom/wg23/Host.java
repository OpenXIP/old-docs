/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.transform.Source;
import javax.xml.ws.Service;
import javax.xml.ws.ServiceMode;
import javax.xml.ws.WebServiceProvider;

/**
 * @author Jaroslaw Krych
 *
 */
@WebService()
@ServiceMode(value=Service.Mode.PAYLOAD)
public class Host implements HostInterface{
	@WebMethod()
	public String generateUID() {
		// TODO Auto-generated method stub
		return null;
	}
	@WebMethod()
	public NativeObjectLocator[] getAsFile(NativeObjectDescriptor[] nativeObjectDescriptor) {
		// TODO Auto-generated method stub
		return null;
	}
	@WebMethod()
	public NativeObjectDescriptor[] getNativeObjectDescriptors() {
		// TODO Auto-generated method stub
		return null;
	}
	@WebMethod()
	public String getOutputDir() {
		// TODO Auto-generated method stub
		return null;
	}
	@WebMethod()
	public String getTmpDir() {
		// TODO Auto-generated method stub
		return null;
	}
	@WebMethod()
	public void notifyOutputAvailable() {
		// TODO Auto-generated method stub
		
	}
	@WebMethod()
	public void notifyStateChanged(State state) {
		// TODO Auto-generated method stub
		
	}
	@WebMethod()
	public void notifyStatus(Status status) {
		// TODO Auto-generated method stub		
	}
	@WebMethod()
	public Rectangle getAvailableScreen(Rectangle appPreferredScreen) {
		// TODO Auto-generated method stub
		return null;
	}	
	@WebMethod()
	public String[] queryNativeModel1(NativeObjectDescriptor nativeObject, String xPathQuery) {
		// TODO Auto-generated method stub
		return null;
	}
	@WebMethod()
	public List<String> queryNativeModel2(NativeObjectDescriptor nativeObject, String xPathQuery) {
		// TODO Auto-generated method stub
		return null;
	}	
	@WebMethod()
	public byte[] queryNativeModel3(NativeObjectDescriptor nativeObject, String xPathQuery) {
		// TODO Auto-generated method stub
		return null;
	}
	@WebMethod()	
	public Source queryNativeModel4(NativeObjectDescriptor nativeObject, String xPathQuery) {
		// TODO Auto-generated method stub
		return null;
	}
}
