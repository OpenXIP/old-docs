
package org.nema.dicom.wg23.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.transform.Source;

@XmlRootElement(name = "queryNativeModel4Response", namespace = "http://wg23.dicom.nema.org/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryNativeModel4Response", namespace = "http://wg23.dicom.nema.org/")
public class QueryNativeModel4Response {

    @XmlElement(name = "return", namespace = "")
    private Source _return;

    /**
     * 
     * @return
     *     returns Source
     */
    public Source get_return() {
        return this._return;
    }

    /**
     * 
     * @param _return
     *     the value for the _return property
     */
    public void set_return(Source _return) {
        this._return = _return;
    }

}
