/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * @author Jaroslaw Krych
 *
 */
@WebService()
public class Application implements ApplicationInterface{
	@WebMethod()
	public NativeObjectLocator[] getAsFile(NativeObjectDescriptor[] nativeObjectDescriptor) {
		// TODO Auto-generated method stub
		return null;
	}	
	@WebMethod()
	public NativeObjectDescriptor[] getNativeObjectDescriptors() {
		// TODO Auto-generated method stub
		return null;
	}
	@WebMethod()
	public State getState() {
		// TODO Auto-generated method stub
		return null;
	}
	@WebMethod()
	public Boolean setState(State state) {
		// TODO Auto-generated method stub
		return null;
	}
	@WebMethod()
	public Boolean bringToFront() {
		// TODO Auto-generated method stub
		return null;
	}
}
