/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23;
/**
 * @author Jaroslaw Krych
 *
 */
public class NativeObjectDescriptor {
	String strUUID;	
	String mimeType;
	String sopClassUID;
	
	/* Generate UUID for non-Dicom objects
	 * Use Dicom SOP Instance UID for Dicom objects
	 */
	public String getUUID(){
		return strUUID;
	}
	public void setUUID(String strUUID){
		this.strUUID = strUUID;
	}
	public String getMimeType(){
		return mimeType;
	}
	public void setMimeType(String mimeType){
		this.mimeType = mimeType;
	}
	public String getSOPClassUID(){
		return sopClassUID;
	}
	public void setSOPClassUID(String sopClassUID){
		this.sopClassUID = sopClassUID;
	}
}
