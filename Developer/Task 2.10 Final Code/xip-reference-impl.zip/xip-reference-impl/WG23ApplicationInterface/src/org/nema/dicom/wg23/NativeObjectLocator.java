/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23;

import java.net.URI;
/**
 * @author Jaroslaw Krych
 *
 */
public class NativeObjectLocator {
	String strUUID;
	URI uri;
	
	public String getUUID(){
		return strUUID;
	}
	public void setUUID(String strUUID){
		this.strUUID = strUUID;
	}
	public URI getURI(){
		return uri;
	}
	public void setURI(URI uri){
		this.uri = uri;
	}
}
