/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23;

/**
 * @author Jaroslaw Krych
 *
 */
public enum StatusType {	
	INFORMATION, ERROR, WARNING, FATALERROR
}
