
package org.nema.dicom.wg23.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.nema.dicom.wg23.NativeObjectDescriptor;

@XmlRootElement(name = "getNativeObjectDescriptorsResponse", namespace = "http://wg23.dicom.nema.org/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getNativeObjectDescriptorsResponse", namespace = "http://wg23.dicom.nema.org/")
public class GetNativeObjectDescriptorsResponse {

    @XmlElement(name = "return", namespace = "")
    private NativeObjectDescriptor[] _return;

    /**
     * 
     * @return
     *     returns NativeObjectDescriptor[]
     */
    public NativeObjectDescriptor[] get_return() {
        return this._return;
    }

    /**
     * 
     * @param _return
     *     the value for the _return property
     */
    public void set_return(NativeObjectDescriptor[] _return) {
        this._return = _return;
    }

}
