
package org.nema.dicom.wg23.clientToApplication.clientArtifacts;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.nema.dicom.wg23.clientToApplication.clientArtifacts package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SetStateResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "setStateResponse");
    private final static QName _GetAsFile_QNAME = new QName("http://wg23.dicom.nema.org/", "getAsFile");
    private final static QName _GetState_QNAME = new QName("http://wg23.dicom.nema.org/", "getState");
    private final static QName _BringToFrontResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "bringToFrontResponse");
    private final static QName _GetAsFileResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "getAsFileResponse");
    private final static QName _GetNativeObjectDescriptorsResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "getNativeObjectDescriptorsResponse");
    private final static QName _GetNativeObjectDescriptors_QNAME = new QName("http://wg23.dicom.nema.org/", "getNativeObjectDescriptors");
    private final static QName _GetStateResponse_QNAME = new QName("http://wg23.dicom.nema.org/", "getStateResponse");
    private final static QName _BringToFront_QNAME = new QName("http://wg23.dicom.nema.org/", "bringToFront");
    private final static QName _SetState_QNAME = new QName("http://wg23.dicom.nema.org/", "setState");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.nema.dicom.wg23.clientToApplication.clientArtifacts
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetAsFileResponse }
     * 
     */
    public GetAsFileResponse createGetAsFileResponse() {
        return new GetAsFileResponse();
    }

    /**
     * Create an instance of {@link GetAsFile }
     * 
     */
    public GetAsFile createGetAsFile() {
        return new GetAsFile();
    }

    /**
     * Create an instance of {@link GetNativeObjectDescriptors }
     * 
     */
    public GetNativeObjectDescriptors createGetNativeObjectDescriptors() {
        return new GetNativeObjectDescriptors();
    }

    /**
     * Create an instance of {@link GetState }
     * 
     */
    public GetState createGetState() {
        return new GetState();
    }

    /**
     * Create an instance of {@link NativeObjectDescriptor }
     * 
     */
    public NativeObjectDescriptor createNativeObjectDescriptor() {
        return new NativeObjectDescriptor();
    }

    /**
     * Create an instance of {@link SetState }
     * 
     */
    public SetState createSetState() {
        return new SetState();
    }

    /**
     * Create an instance of {@link GetNativeObjectDescriptorsResponse }
     * 
     */
    public GetNativeObjectDescriptorsResponse createGetNativeObjectDescriptorsResponse() {
        return new GetNativeObjectDescriptorsResponse();
    }

    /**
     * Create an instance of {@link SetStateResponse }
     * 
     */
    public SetStateResponse createSetStateResponse() {
        return new SetStateResponse();
    }

    /**
     * Create an instance of {@link NativeObjectLocator }
     * 
     */
    public NativeObjectLocator createNativeObjectLocator() {
        return new NativeObjectLocator();
    }

    /**
     * Create an instance of {@link BringToFront }
     * 
     */
    public BringToFront createBringToFront() {
        return new BringToFront();
    }

    /**
     * Create an instance of {@link GetStateResponse }
     * 
     */
    public GetStateResponse createGetStateResponse() {
        return new GetStateResponse();
    }

    /**
     * Create an instance of {@link BringToFrontResponse }
     * 
     */
    public BringToFrontResponse createBringToFrontResponse() {
        return new BringToFrontResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetStateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "setStateResponse")
    public JAXBElement<SetStateResponse> createSetStateResponse(SetStateResponse value) {
        return new JAXBElement<SetStateResponse>(_SetStateResponse_QNAME, SetStateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAsFile }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getAsFile")
    public JAXBElement<GetAsFile> createGetAsFile(GetAsFile value) {
        return new JAXBElement<GetAsFile>(_GetAsFile_QNAME, GetAsFile.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetState }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getState")
    public JAXBElement<GetState> createGetState(GetState value) {
        return new JAXBElement<GetState>(_GetState_QNAME, GetState.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BringToFrontResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "bringToFrontResponse")
    public JAXBElement<BringToFrontResponse> createBringToFrontResponse(BringToFrontResponse value) {
        return new JAXBElement<BringToFrontResponse>(_BringToFrontResponse_QNAME, BringToFrontResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAsFileResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getAsFileResponse")
    public JAXBElement<GetAsFileResponse> createGetAsFileResponse(GetAsFileResponse value) {
        return new JAXBElement<GetAsFileResponse>(_GetAsFileResponse_QNAME, GetAsFileResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetNativeObjectDescriptorsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getNativeObjectDescriptorsResponse")
    public JAXBElement<GetNativeObjectDescriptorsResponse> createGetNativeObjectDescriptorsResponse(GetNativeObjectDescriptorsResponse value) {
        return new JAXBElement<GetNativeObjectDescriptorsResponse>(_GetNativeObjectDescriptorsResponse_QNAME, GetNativeObjectDescriptorsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetNativeObjectDescriptors }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getNativeObjectDescriptors")
    public JAXBElement<GetNativeObjectDescriptors> createGetNativeObjectDescriptors(GetNativeObjectDescriptors value) {
        return new JAXBElement<GetNativeObjectDescriptors>(_GetNativeObjectDescriptors_QNAME, GetNativeObjectDescriptors.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "getStateResponse")
    public JAXBElement<GetStateResponse> createGetStateResponse(GetStateResponse value) {
        return new JAXBElement<GetStateResponse>(_GetStateResponse_QNAME, GetStateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BringToFront }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "bringToFront")
    public JAXBElement<BringToFront> createBringToFront(BringToFront value) {
        return new JAXBElement<BringToFront>(_BringToFront_QNAME, BringToFront.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetState }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wg23.dicom.nema.org/", name = "setState")
    public JAXBElement<SetState> createSetState(SetState value) {
        return new JAXBElement<SetState>(_SetState_QNAME, SetState.class, null, value);
    }

}
