
package org.nema.dicom.wg23.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "bringToFrontResponse", namespace = "http://wg23.dicom.nema.org/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bringToFrontResponse", namespace = "http://wg23.dicom.nema.org/")
public class BringToFrontResponse {

    @XmlElement(name = "return", namespace = "")
    private Boolean _return;

    /**
     * 
     * @return
     *     returns Boolean
     */
    public Boolean get_return() {
        return this._return;
    }

    /**
     * 
     * @param _return
     *     the value for the _return property
     */
    public void set_return(Boolean _return) {
        this._return = _return;
    }

}
