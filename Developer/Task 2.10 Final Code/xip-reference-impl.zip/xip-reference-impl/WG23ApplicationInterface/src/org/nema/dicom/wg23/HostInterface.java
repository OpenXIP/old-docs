/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23;

/**
 * @author Jaroslaw Krych
 *
 */
public interface HostInterface {			
	public String getTmpDir();
	public String getOutputDir();
	public Rectangle getAvailableScreen(Rectangle appPreferredScreen);
	public String generateUID();			
	public void notifyStateChanged(State state);	 		
	public NativeObjectDescriptor[] getNativeObjectDescriptors();	
	public NativeObjectLocator[] getAsFile(NativeObjectDescriptor[] nativeObjectDescriptor);
	public void notifyOutputAvailable();
	public void notifyStatus(Status status);
}
