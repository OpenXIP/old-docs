/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23;

/**
 * @author Jaroslaw Krych
 *
 */
public class Rectangle{
	int refPointX;
	int refPointY;
	int screenWidth;
	int screenHeight;
	
	public int getRefPointX(){
		return this.refPointX;
	}
	public void setRefPointX (int refPointX ){
		this.refPointX = refPointX;
	}
	public int getRefPointY(){
		return this.refPointY;
	}
	public void setRefPointY (int refPointY){
		this.refPointY = refPointY;
	}
	public int getScreenWidth (){
		return this.screenWidth;
	}
	public void setScreenWidth (int screenWidth){
		this.screenWidth = screenWidth;
	}
	public int getScreenHeight (){
		return this.screenHeight;
	}
	public void setScreenHeight (int screenHeight){
		this.screenHeight = screenHeight;
	}
}
