/**
 * Copyright (c) 2007 Washington University in Saint Louis. All Rights Reserved.
 */
package org.nema.dicom.wg23;

/**
 * @author Jaroslaw Krych
 *
 */
public interface ApplicationInterface {
	public State getState();
	public Boolean setState(State state);	
	public NativeObjectDescriptor[] getNativeObjectDescriptors();	
	public NativeObjectLocator[] getAsFile(NativeObjectDescriptor[] nativeObjectDescriptor);
	public Boolean bringToFront();
}