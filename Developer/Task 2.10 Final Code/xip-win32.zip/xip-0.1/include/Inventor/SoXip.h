#include <Inventor/SoDB.h>


class INVENTOR_API SoXip
{
public:
	static void init();
};
