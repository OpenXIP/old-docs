cat SoSFVtkAlgorithmOutput.h ../core/emptyline.txt > SoSFVtkAlgorithmOutput.h2
cat SoSFVtkObject.h ../core/emptyline.txt > SoSFVtkObject.h2
cat SoVtkAlgorithmOutput.h ../core/emptyline.txt > SoVtkAlgorithmOutput.h2
cat SoVtkObject.h ../core/emptyline.txt > SoVtkObject.h2
