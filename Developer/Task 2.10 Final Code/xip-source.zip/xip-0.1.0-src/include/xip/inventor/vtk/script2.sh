mv SoSFVtkAlgorithmOutput.h2 SoSFVtkAlgorithmOutput.h
mv SoSFVtkObject.h2 SoSFVtkObject.h
mv SoVtkAlgorithmOutput.h2 SoVtkAlgorithmOutput.h
mv SoVtkObject.h2 SoVtkObject.h
