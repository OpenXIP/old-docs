cat XipDataConnectorBase.h ../core/emptyline.txt > XipDataConnectorBase.h2
cat XipDataObjectBase.h ../core/emptyline.txt > XipDataObjectBase.h2
cat xipivremote.h ../core/emptyline.txt > xipivremote.h2
cat XipRenderActionParams.h ../core/emptyline.txt > XipRenderActionParams.h2
cat XipRequestManager.h ../core/emptyline.txt > XipRequestManager.h2
cat XipStream.h ../core/emptyline.txt > XipStream.h2
