mv XipDataConnectorBase.h2 XipDataConnectorBase.h
mv XipDataObjectBase.h2 XipDataObjectBase.h
mv xipivremote.h2 xipivremote.h
mv XipRenderActionParams.h2 XipRenderActionParams.h
mv XipRequestManager.h2 XipRequestManager.h
mv XipStream.h2 XipStream.h
