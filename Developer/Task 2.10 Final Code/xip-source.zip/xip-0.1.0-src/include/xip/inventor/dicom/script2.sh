mv SoXipDataDicomElement.h2 SoXipDataDicomElement.h
mv SoXipDataDicom.h2 SoXipDataDicom.h
mv SoXipMFDataDicom.h2 SoXipMFDataDicom.h
mv SoXipPState.h2 SoXipPState.h
mv SoXipSFDataDicom.h2 SoXipSFDataDicom.h
mv SoXipSFPState.h2 SoXipSFPState.h
mv xipivdicom.h2 xipivdicom.h
mv xipivDicomUtils.h2 xipivDicomUtils.h
