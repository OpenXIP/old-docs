cat SoXipDataDicomElement.h ../core/emptyline.txt > SoXipDataDicomElement.h2
cat SoXipDataDicom.h ../core/emptyline.txt > SoXipDataDicom.h2
cat SoXipMFDataDicom.h ../core/emptyline.txt > SoXipMFDataDicom.h2
cat SoXipPState.h ../core/emptyline.txt > SoXipPState.h2
cat SoXipSFDataDicom.h ../core/emptyline.txt > SoXipSFDataDicom.h2
cat SoXipSFPState.h ../core/emptyline.txt > SoXipSFPState.h2
cat xipivdicom.h ../core/emptyline.txt > xipivdicom.h2
cat xipivDicomUtils.h ../core/emptyline.txt > xipivDicomUtils.h2
