// Sylvain Jaume 2008

#include <windows.h>

# ifdef __cplusplus
#  include <algorithm>
# endif /* __cplusplus */

typedef __int64 int64_t;

#define snprintf _snprintf
//#define glGetProcAddress wglGetProcAddress
