#ifndef _OSX_DEFINES_H_
#define _OSX_DEFINES_H_

#define KEY_DELETE DELETE

#endif /* _OSX_DEFINES_H_ */
