#ifndef _OSX_STANDARD_H_
#define _OSX_STANDARD_H_

#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <Strings.h>
#include <X11/Xmd.h> // define 'typedef CARD8 BOOL'

#ifdef __cplusplus
#include <string>
#include <algorithm>
#endif /* __cplusplus */

// typedef int64_t __int64;

#endif /* _OSX_STANDARD_H_ */
