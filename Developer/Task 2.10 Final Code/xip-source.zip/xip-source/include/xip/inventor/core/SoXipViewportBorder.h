#ifndef SOXIPVIEWPORTBORDER_H
#define SOXIPVIEWPORTBORDER_H

#include <Inventor/nodes/SoSubNode.h>
#include <Inventor/fields/SoSFColor.h>
#include <Inventor/fields/SoSFFloat.h>
#include <Inventor/fields/SoSFUShort.h>


class SoXipViewportBorder : public SoNode
{
SO_NODE_HEADER(SoXipViewportBorder);

public:
	SoSFColor	activeColor;
	SoSFFloat	activeLineWidth;
	SoSFUShort	activeLinePattern;

	SoSFColor	inactiveColor;
	SoSFFloat	inactiveLineWidth;
	SoSFUShort	inactiveLinePattern;

	/// Static method providing Open Inventor runtype type information.
	static void initClass();

	///	Default constructor
	SoXipViewportBorder();

protected:
	/// Default destructor
	virtual ~SoXipViewportBorder();

protected:
	virtual void GLRender(SoGLRenderAction * action);
};


#endif // SOXIPVIEWPORTBORDER_H
