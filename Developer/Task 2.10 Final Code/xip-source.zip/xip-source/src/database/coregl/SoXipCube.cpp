#include "SoXipCube.h"

SO_NODE_SOURCE(SoXipCube);

SoXipCube::SoXipCube() {
	SO_NODE_CONSTRUCTOR(SoXipCube);

	SO_NODE_ADD_FIELD(scale, (SbVec3f(1, 1, 1)));
	SO_NODE_ADD_FIELD(offset, (SbVec3f(-0.5, -0.5, -0.5)));
	SO_NODE_ADD_FIELD(culling, (NONE));

	SO_NODE_DEFINE_ENUM_VALUE(Culling, NONE);
	SO_NODE_DEFINE_ENUM_VALUE(Culling, FRONT);
	SO_NODE_DEFINE_ENUM_VALUE(Culling, BACK);
	SO_NODE_SET_SF_ENUM_TYPE(culling, Culling);
}

void SoXipCube::initClass() {
	SO_NODE_INIT_CLASS(SoXipCube, SoNode, "SoNode");
}

void SoXipCube::GLRender(SoGLRenderAction* action) {
	SbVec3f vertices[8] = {
		SbVec3f(0, 0, 0),
		SbVec3f(1, 0, 0),
		SbVec3f(0, 1, 0),
		SbVec3f(1, 1, 0),
		SbVec3f(0, 0, 1),
		SbVec3f(1, 0, 1),
		SbVec3f(0, 1, 1),
		SbVec3f(1, 1, 1),
	};

	SbVec3f tVertices[8];

	int indices[24] = {0, 2, 3, 1, 4, 5, 7, 6, 0, 1, 5, 4, 2, 6, 7, 3, 0, 4, 6, 2, 1, 3, 7, 5};

	GLenum cullFace = culling.getValue();

	if (cullFace) {
		glPushAttrib(GL_ENABLE_BIT);
		glEnable(GL_CULL_FACE);
		glCullFace(cullFace);
	}

	const SbVec3f &vScale = scale.getValue();
	const SbVec3f &vOffset = offset.getValue();

	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 3; j++) {
			tVertices[i][j] = (vertices[i][j] + vOffset[j]) * vScale[j];
		}
	}

	glBegin(GL_QUADS);
	for (int i = 0; i < 24; i++) {
		glTexCoord3fv(&vertices[indices[i]][0]);
		glVertex3fv(&tVertices[indices[i]][0]);
	}
	glEnd();

	if (cullFace) {
		glPopAttrib();
	}
}
