#include <xip/inventor/core/SoXipSFDataImage.h>
#include <xip/inventor/core/SoXipDataImage.h>
#include <xip/inventor/core/SbXipImage.h>
#include <Inventor/errors/SoMemoryError.h>
#include "SoXipLoadRaw.h"
#include "SbXipDirtyFieldList.h"

SO_ENGINE_SOURCE( SoXipLoadRaw );

SoXipLoadRaw::SoXipLoadRaw()
{
	SO_ENGINE_CONSTRUCTOR( SoXipLoadRaw );

	SO_ENGINE_DEFINE_ENUM_VALUE( VoxelType, UBYTE );
	SO_ENGINE_DEFINE_ENUM_VALUE( VoxelType, USHORT );
    SO_ENGINE_DEFINE_ENUM_VALUE( VoxelType, SHORT );
	 SO_ENGINE_DEFINE_ENUM_VALUE( VoxelType, FLOAT32 );
	SO_ENGINE_SET_SF_ENUM_TYPE( voxelType, VoxelType );

	SO_ENGINE_ADD_INPUT( voxelType, (UBYTE) );
	SO_ENGINE_ADD_INPUT( width, (0 ));
	SO_ENGINE_ADD_INPUT( height, (0) );
	SO_ENGINE_ADD_INPUT( depth, (0) );
	SO_ENGINE_ADD_INPUT( bitsUsed, (8) );
	SO_ENGINE_ADD_INPUT( modelMatrix, (SbMatrix::identity()) );
	SO_ENGINE_ADD_INPUT( file, ("") );

	SO_ENGINE_ADD_OUTPUT( output, SoXipSFDataImage);

	mDataOutput = 0;
}

SoXipLoadRaw::~SoXipLoadRaw()
{
	SbXipDirtyFieldList::remove( &file );

	if( mDataOutput )
	{
		mDataOutput->unref();
		mDataOutput = 0;
	}
}

void 
SoXipLoadRaw::initClass()
{
	SO_ENGINE_INIT_CLASS( SoXipLoadRaw, SoEngine, "Engine" );
}

void
SoXipLoadRaw::evaluate()
{
	// Reset the previous outputs
	if( mDataOutput )
	{
		mDataOutput->unref();
		mDataOutput = 0;
		SO_ENGINE_OUTPUT( output, SoXipSFDataImage, setValue(0) );
	}

    SbXipImage* img = 0;
    try
    {
	    if( (width.getValue() > 0) &&
		    (height.getValue() > 0) &&
		    (depth.getValue() > 0) &&
		    (bitsUsed.getValue() > 0) &&
		    (file.getValue().getLength() > 0) )
	    {
            int voxelStorageType = voxelType.getValue();

            SbXipImage::DataType xipDataType;
            switch (voxelStorageType)
            {
            case UBYTE:
                xipDataType = SbXipImage::UNSIGNED_BYTE;
                break;
            case USHORT:
                xipDataType = SbXipImage::UNSIGNED_SHORT;
                break;
            case SHORT:
                xipDataType = SbXipImage::SHORT;
                break;
				case FLOAT32:
					xipDataType = SbXipImage::FLOAT;
                break;
            default:
				SoError::post( "Unsupported image type" );
				goto error;
            }

		    img = new SbXipImage(
			    SbXipImageDimensions( width.getValue(), height.getValue(), depth.getValue() ),
			    xipDataType,
			    bitsUsed.getValue(), 1, SbXipImage::SEPARATE, SbXipImage::LUMINANCE,
				modelMatrix.getValue() );

            if( !img )
            {
				SoMemoryError::post( "Error allocating image" );
				goto error;
            }

		    if( !img->read( file.getValue().getString(), 0 ) )
		    {
                SoError::post( "Reading raw image data from \"%s\" failed!", file.getValue().getString() );
				goto error;
			}
		    
			mDataOutput = new SoXipDataImage;
            if( !mDataOutput )
			{
				SoMemoryError::post( "Error allocating data image" );
				goto error;
			}

			mDataOutput->ref();
			mDataOutput->set( img );

			// Update output
			SO_ENGINE_OUTPUT( output, SoXipSFDataImage, setValue( mDataOutput ) );
	    }
    }
	catch(...)
	{
		SoError::post( "Unknown exception: loading raw data from \"%s\" failed!",
			file.getValue().getString() );
		goto error;
	}

	return ;

// Error handling
error:
	if( mDataOutput )
	{
		mDataOutput->unref();
		mDataOutput = 0;
	}
	if( img )
	{
		delete img;
        img = 0;
	}
}

SbBool
SoXipLoadRaw::readInstance( SoInput* in, unsigned short flags )
{
	#if defined(COIN_DLL) || defined (COIN_NO_DLL)
	// SGI automatically triggers evaluate after loading but COIN doesn't
	SbXipDirtyFieldList::append(&file);
	#endif

	return SoEngine::readInstance( in, flags );
}