#include <xip/inventor/core/SoXipExaminer.h>
#include <Inventor/sensors/SoFieldSensor.h>
#include <Inventor/sensors/SoTimerSensor.h>
#include <Inventor/nodes/SoPerspectiveCamera.h>
#include <Inventor/nodes/SoOrthographicCamera.h>
#include <Inventor/nodes/SoSwitch.h>
#include <Inventor/elements/SoViewportRegionElement.h>
#include <Inventor/events/SoMouseButtonEvent.h>
#include <Inventor/events/SoLocation2Event.h>
#include <Inventor/projectors/SbPlaneProjector.h>
#include <Inventor/projectors/SbSphereSheetProjector.h>
#include <Inventor/projectors/SbLineProjector.h>
#include <Inventor/elements/SoViewportRegionElement.h>
#include <Inventor/elements/SoViewVolumeElement.h>
#include <Inventor/elements/SoModelMatrixElement.h>
#include <xip/inventor/core/SoXipRenderModeElement.h>
#include <Inventor/nodes/SoAnnotation.h>
#include <Inventor/elements/SoInt32Element.h>

#include <xip/inventor/core/SoXipCursor.h>
#include <xip/inventor/core/SoXipActiveViewportElement.h>

#define ROT_BUFF_SIZE 3


SO_KIT_SOURCE(SoXipExaminer);

SbBool isVecInObjectSpace(const SbVec3f &vec, float halfLen)
{
	for (int i = 0; i < 3; i++) if (fabs(vec[i]) > halfLen) return FALSE;

	return TRUE;
}


SoXipExaminer::SoXipExaminer()
{
	SO_KIT_CONSTRUCTOR(SoXipExaminer);

	isBuiltIn = TRUE;
	mViewAll = FALSE;
	mResetPlane = FALSE;
	mDragMouseButton = SoMouseButtonEvent::BUTTON1;
	mViewVolume.ortho(-1, 1, -1, 1, 1, 10);
	mVpRegion = SbViewportRegion(1, 1);
	mViewTransform = SbMatrix::identity();
	mLastMousePos = mMouseDownPos = SbVec2f(0, 0);

	mPlaneProj = new SbPlaneProjector(FALSE);
	mPlaneProj->setPlane(SbPlane(SbVec3f(0, 0, 1), 0));

    mSphereSheetProj = new SbSphereSheetProjector;
    mSphereSheetProj->setViewVolume(mViewVolume);
    mSphereSheetProj->setSphere(SbSphere(SbVec3f(0, 0, 0), .7));

	mIsFirstMouseDown = FALSE;
	mLastHandleEventTime.setToTimeOfDay();

	// Initialize children catalog and add entries to it:
	//
	//     cameraSwitch  complexity
	//          |
	//      +--------+
	//      |        |
	//    ortho perspective
	//
	SO_KIT_ADD_CATALOG_ENTRY(cameraSwitch, SoSwitch, FALSE, this, \0 , FALSE);
	SO_KIT_ADD_CATALOG_ENTRY(annotation, SoAnnotation, FALSE, this, \0 , FALSE);
	SO_KIT_ADD_CATALOG_ENTRY(complexity, SoComplexity, FALSE, this, \0 , FALSE);
	SO_KIT_ADD_CATALOG_ENTRY(orthoCamera, SoOrthographicCamera, FALSE, cameraSwitch, \0 , FALSE);
	SO_KIT_ADD_CATALOG_ENTRY(perspectiveCamera, SoPerspectiveCamera, FALSE, cameraSwitch, \0 , FALSE);
	SO_KIT_ADD_CATALOG_ENTRY(borderSwitch, SoSwitch, FALSE, annotation, \0 , FALSE);
	SO_KIT_ADD_CATALOG_ENTRY(borderNode, SoXipViewportBorder, FALSE, borderSwitch, \0 , FALSE);

	SO_KIT_INIT_INSTANCE();

	SO_NODE_ADD_FIELD(perspective, (TRUE));

	SO_NODE_DEFINE_ENUM_VALUE(orientationType, FEET);
	SO_NODE_DEFINE_ENUM_VALUE(orientationType, HEAD);
	SO_NODE_DEFINE_ENUM_VALUE(orientationType, LEFT);
	SO_NODE_DEFINE_ENUM_VALUE(orientationType, RIGHT);
	SO_NODE_DEFINE_ENUM_VALUE(orientationType, ANTERIOR);
	SO_NODE_DEFINE_ENUM_VALUE(orientationType, POSTERIOR);

	SO_NODE_DEFINE_ENUM_VALUE(orientationType, RANGE_START);
	SO_NODE_DEFINE_ENUM_VALUE(orientationType, RANGE_END);
	SO_NODE_DEFINE_ENUM_VALUE(orientationType, AZIMUTH_START);
	SO_NODE_DEFINE_ENUM_VALUE(orientationType, AZIMUTH_END);
	SO_NODE_DEFINE_ENUM_VALUE(orientationType, ELEVATION_START);
	SO_NODE_DEFINE_ENUM_VALUE(orientationType, ELEVATION_END);

	SO_NODE_SET_SF_ENUM_TYPE(orientation, orientationType);
	SO_NODE_ADD_FIELD(orientation, (FEET));
	SO_NODE_ADD_FIELD(viewOrientation, ());

	SO_NODE_ADD_FIELD(viewAll, ());
	SO_NODE_ADD_FIELD(resetPlane, ());

	SO_NODE_DEFINE_ENUM_VALUE(modeType, NONE);
	SO_NODE_DEFINE_ENUM_VALUE(modeType, ROTATE);
	SO_NODE_DEFINE_ENUM_VALUE(modeType, PANZOOM);
	SO_NODE_DEFINE_ENUM_VALUE(modeType, ROTATE_PLANE);
	SO_NODE_DEFINE_ENUM_VALUE(modeType, TRANSLATE_PLANE);
	SO_NODE_SET_SF_ENUM_TYPE(mode, modeType);
	SO_NODE_ADD_FIELD(mode, (NONE));
	SO_NODE_ADD_FIELD(pointTo, (FALSE));
	SO_NODE_ADD_FIELD(border, (FALSE));
	SO_NODE_ADD_FIELD(borderColor, (SbColor(0.7, 0.7, 0.7)));
	SO_NODE_ADD_FIELD(autoSpin, (FALSE));

	SO_NODE_ADD_FIELD(rotateCamera, (SbRotation(SbVec3f(0, 0, 1), 0)));
	SO_NODE_ADD_FIELD(scaleHeight, (1.0f));

	SO_NODE_ADD_FIELD(viewBoundingBox, (SbMatrix::identity()));
	SO_NODE_ADD_FIELD(plane, (SbPlane(SbVec3f(0, 0, 1), 0)));

	SO_NODE_ADD_FIELD(pickedPoint, (0, 0, 0));
	

	SoField *fields[] = { &viewAll, &perspective, &resetPlane, &viewOrientation, &rotateCamera, &scaleHeight };
	for (int i = 0; i < (sizeof(fields) / sizeof(SoField*)); i++)
	{
		SoFieldSensor *fieldSensor = new SoFieldSensor(&fieldSensorCBFunc, this);
		fieldSensor->attach(fields[i]);
		mInputSensors.push_back(fieldSensor);
	}

	mTimerSensor = new SoTimerSensor(timerSensorCBFunc, this);
	mTimerSensor->setInterval(0.05);	// 20 fps

	mRotBuffer = new SbRotation[ROT_BUFF_SIZE];

	SoSwitch *cameraSwitch = (SoSwitch*) getAnyPart("cameraSwitch", TRUE);
	cameraSwitch->whichChild.setValue(perspective.getValue());
}


SoXipExaminer::~SoXipExaminer()
{
	delete mPlaneProj;
	delete mSphereSheetProj;
	delete [] mRotBuffer;

	std::vector<SoFieldSensor *>::iterator i;
	for (i = mInputSensors.begin(); i != mInputSensors.end(); i++)
	{
		delete (*i);
	}

	if (mTimerSensor)
	{
		delete mTimerSensor;
	}
}


void SoXipExaminer::initClass()
{
	SO_KIT_INIT_CLASS(SoXipExaminer, SoBaseKit, "BaseKit");

//	SO_ENABLE(SoHandleEventAction, SoRadMprPlaneElement);
	SO_ENABLE(SoHandleEventAction, SoViewportRegionElement);
	SO_ENABLE(SoHandleEventAction, SoViewVolumeElement);
	SO_ENABLE(SoHandleEventAction, SoModelMatrixElement);
    SO_ENABLE(SoHandleEventAction, SoXipRenderModeElement);
}


void SoXipExaminer::extractViewingParams(SoHandleEventAction *action)
{
	if (!action) 
	{
		// If the action is NULL, use default values for view info.
		mViewVolume.ortho(-1, 1, -1, 1, 1, 10);
		mVpRegion = SbViewportRegion(1, 1);
	}
	else 
	{
		// Get the view info from the action.
		SoState *state = action->getState();
		mViewVolume = SoViewVolumeElement::get(state);
		mVpRegion = SoViewportRegionElement::get(state);
		mViewTransform = SoModelMatrixElement::get(state);
	}
}


SbVec2f SoXipExaminer::getMousePosNormalized(SoHandleEventAction *action)
{
	const SoEvent *e = action->getEvent();

	if (action->getGrabber() != this)
	{
		extractViewingParams(action);
	}

	return e->getNormalizedPosition(mVpRegion);
}


SoCamera *SoXipExaminer::getCamera()
{
	return (SoCamera*) (perspective.getValue() ? getAnyPart("perspectiveCamera", TRUE) : getAnyPart("orthoCamera", TRUE));
}


void SoXipExaminer::inputChanged(SoField *which)
{
	if (which == &viewAll)
	{
		mViewAll = TRUE;
		touch();
	}
	else if (which == &resetPlane)
	{
		mResetPlane = TRUE;
		touch();
	}
	else if (which == &perspective)
	{
		SoSwitch *cameraSwitch = (SoSwitch*) getAnyPart("cameraSwitch", TRUE);

		if (cameraSwitch->whichChild.getValue() != perspective.getValue())
		{
			SoCamera *from, *to;
			if (perspective.getValue())
			{
				from = (SoCamera*) getAnyPart("orthoCamera", TRUE);
				to = (SoCamera*) getAnyPart("perspectiveCamera", TRUE);
			}
			else
			{
				to = (SoCamera*) getAnyPart("orthoCamera", TRUE);
				from = (SoCamera*) getAnyPart("perspectiveCamera", TRUE);
			}

			to->viewportMapping = from->viewportMapping;
			to->position        = from->position;
			to->orientation     = from->orientation;
			to->aspectRatio     = from->aspectRatio;
			to->nearDistance    = from->nearDistance;
			to->farDistance     = from->farDistance;
			to->focalDistance   = from->focalDistance;

			cameraSwitch->whichChild.setValue(perspective.getValue());
		}
	}
	else if (which == &viewOrientation)
	{
		SbRotation rot, oldRot;
		rot = oldRot = getCamera()->orientation.getValue();

		switch (orientation.getValue())
		{
		case FEET:		rot = SbRotation(SbVec3f(1, 0, 0), M_PI); break;
		case HEAD:		rot = SbRotation(SbVec3f(0, 0, 1), M_PI); break;
		case LEFT:		rot = SbRotation(SbVec3f(0, 0, 1),  M_PI / 2.f) * SbRotation(SbVec3f(0, 1, 0),  M_PI / 2.f); break;
		case RIGHT:		rot = SbRotation(SbVec3f(0, 0, 1), -M_PI / 2.f) * SbRotation(SbVec3f(0, 1, 0), -M_PI / 2.f); break;
		case ANTERIOR:	rot = SbRotation(SbVec3f(1, 0, 0), M_PI / 2.f); break;
		case POSTERIOR:	rot = SbRotation(SbVec3f(0, 1, 0), M_PI) * SbRotation(SbVec3f(1, 0, 0), M_PI / 2.f); break;
		case RANGE_START: rot = SbRotation(SbVec3f(0, 1, 0), -M_PI / 2.f); break;
		case RANGE_END:   rot = SbRotation(SbVec3f(0, 1, 0), M_PI / 2.f); break;
		case AZIMUTH_START: rot = SbRotation(SbVec3f(0, 0, 1),  M_PI / 2.f); break;
		case AZIMUTH_END: rot = SbRotation(SbVec3f(0, 1, 0),  M_PI) * SbRotation(SbVec3f(0, 0, 1),  M_PI / 2.f); break;
		case ELEVATION_START: rot = SbRotation(SbVec3f(0, 1, 0),  M_PI / 2.f) * SbRotation(SbVec3f(0, 0, 1),  M_PI / 2.f); break;
		case ELEVATION_END: rot = SbRotation(SbVec3f(0, 1, 0),  -M_PI / 2.f) * SbRotation(SbVec3f(0, 0, 1),  M_PI / 2.f); break;
		}

		rotateCam(rot * oldRot.inverse());
	}
	else if (which == &rotateCamera)
	{
		rotateCam(rotateCamera.getValue());
	}
	else if (which == &scaleHeight)
	{
		scaleCam(scaleHeight.getValue());
	}
}

void SoXipExaminer::timer(SoSensor *sensor)
{
	if (mode.getValue() == ROTATE)
	{
		rotateCam(mAutoSpinRotation);
	}
	else
	{
		// stop timer if user switched mode
		if (mTimerSensor->isScheduled())
			mTimerSensor->unschedule();
	}
}


void SoXipExaminer::fieldSensorCBFunc(void *usr, SoSensor *sensor)
{
	((SoXipExaminer*)usr)->inputChanged(((SoFieldSensor*) sensor)->getAttachedField());
}


void SoXipExaminer::timerSensorCBFunc(void *usr, SoSensor *sensor)
{
	((SoXipExaminer*)usr)->timer(sensor);
}

#include <Inventor/elements/SoInt32Element.h>


void SoXipExaminer::GLRender(SoGLRenderAction * action)
{
	if (SoXipActiveViewportElement::get(action->getState()))
	{
		// whenever this is not the active segment the next mouse click is for activation only
		mIsFirstMouseDown = TRUE;
	}

	SoSwitch *onOff = (SoSwitch*) getAnyPart("borderSwitch", TRUE);
	if (onOff)
	{
		if (onOff->whichChild.getValue() != (border.getValue() ? 0 : -1))
			onOff->whichChild.setValue(border.getValue() ? 0 : -1);
	}

	/*
	SoRadViewportBorder *b = (SoRadViewportBorder*) getAnyPart("borderNode", TRUE);
	if ((b->activeColor.getValue() != borderColor.getValue()) || (b->inactiveColor.getValue() != borderColor.getValue()))
	{
		b->activeColor.setValue(borderColor.getValue());
		b->inactiveColor.setValue(borderColor.getValue());
	}*/			

	if (mViewAll)
	{
		SbViewportRegion viewportRegion = SoViewportRegionElement::get(action->getState());

		const SoPath *path = action->getCurPath();
		if (path)
		{
			// get the node one before this
			SoNode *node = path->getNodeFromTail(1);
			if (node)
			{
				if (getCamera()->isOfType(SoPerspectiveCamera::getClassTypeId()))
				{
					((SoPerspectiveCamera*) getCamera())->heightAngle.setValue((45.f / 180.) * M_PI);
				}

				getCamera()->viewAll(node, viewportRegion);
				//getCamera()->scaleHeight(scaleHeight.getValue());

				// compute bounding box
				SoGetBoundingBoxAction action(viewportRegion);

				// Find the bounding box of the scene
				action.apply(node);

				SbBox3f box = action.getBoundingBox();

				if (!box.isEmpty())
				{
					SbVec3f origin, size;

					box.getOrigin(origin[0], origin[1], origin[2]);
					box.getSize(size[0], size[1], size[2]);

					SbMatrix m;
					m.setTransform(origin, SbRotation(SbMatrix::identity()), size);
					viewBoundingBox.setValue(m);
				}
				else
				{
					viewBoundingBox.setValue(SbMatrix::identity());
				}
			}
		}

		mViewAll = FALSE;
	}

	if (mResetPlane)
	{
		SbRotation camRot = getCamera()->orientation.getValue();
		float radius = getCamera()->focalDistance.getValue();
		SbMatrix m;
		m = camRot;
		SbVec3f dir(-m[2][0], -m[2][1], -m[2][2]);
		SbVec3f center = getCamera()->position.getValue() + dir * radius;

		plane.setValue(SbPlane(dir, center));

		mResetPlane = FALSE;
	}

	SoBaseKit::GLRender(action); 
}


void SoXipExaminer::updateCursor()
{
	switch (mode.getValue())
	{
	case PANZOOM:	if (mDragStartMouseBorder)
						SoXipCursor::setCursor(SoXipCursor::SEL_ZOOM);
					else
						SoXipCursor::setCursor(SoXipCursor::SEL_PAN);
					break;
	case ROTATE:	if (mDragStartMouseBorder)
						SoXipCursor::setCursor(SoXipCursor::ROTATE_INPLANE);
					else
						SoXipCursor::setCursor(SoXipCursor::SEL_ROTATE);
					break;
	case ROTATE_PLANE:
					SoXipCursor::setCursor(SoXipCursor::ROTATE_CLIP);
					break;
	case TRANSLATE_PLANE:
					SoXipCursor::setCursor(SoXipCursor::TRANS_CLIP);
					break;
	default:
		SoXipCursor::setCursor();
	}
}


void SoXipExaminer::handleEvent(SoHandleEventAction *action)
{
	if (action->getGrabber() == 0)
	{
		extractViewingParams(action);
	}

	if (mIsFirstMouseDown && border.getValue())
	{
		if (SO_MOUSE_PRESS_EVENT(action->getEvent(), ANY))
		{
			action->setHandled();
			action->setGrabber(this);
			return;
		}
		else if (SO_MOUSE_RELEASE_EVENT(action->getEvent(), ANY) && (action->getGrabber() == this)) 
		{
			action->releaseGrabber();
			mIsFirstMouseDown = FALSE;
			action->setHandled();
			return;
		}
		else if (action->getEvent()->isOfType(SoLocation2Event::getClassTypeId()))
		{
			SbVec2f pos = getMousePosNormalized(action);
			if ((pos[0] >= 0.f) && (pos[0] <= 1.f) &&
				(pos[1] >= 0.f) && (pos[1] <= 1.f))
			{
				SoXipCursor::setCursor();
			}
			return;
		}
	}

	mHandleEventAction = action;

	SbBool handled = FALSE;
	const SoEvent *e = action->getEvent();

	// call base class first
	SoBaseKit::handleEvent(action);

	if (!pointTo.getValue() && (mode.getValue() == NONE))
	{
		// do nothing
		return;
	}

	if (SoMouseButtonEvent::isButtonPressEvent(e, mDragMouseButton))
	{
		if ((action->getGrabber() != this) && !e->wasShiftDown() && !e->wasCtrlDown())
		{
			/*
			// get MPR planes
			mMprPlaneList.clear();
			SoRadMprPlaneElement *element = SoRadMprPlaneElement::getInstance(action->getState());
			if (element)
			{
				int numPlanes = element->getNum();

				for (int i = 0; i < numPlanes; i++)
				{
					mprPlanes_s entry;

					entry.matrixField = element->getMatrixField(i);
					entry.centerField = element->getCenterField(i);

					if (entry.matrixField)
					{
						mMprPlaneList.push_back(entry);
					}
				}
			}*/

			// need to save viewing parameters because after grabbing we are called
			// directly (camera etc. will be skipped)
			extractViewingParams(action);

			SbVec2f pos = getMousePosNormalized(action);
			if (!((pos[0] >= 0.f) && (pos[0] <= 1.f) &&
				(pos[1] >= 0.f) && (pos[1] <= 1.f)))
			{
				// ignore click outside current viewport
				return;
			}

			// reset the animation queue
			if (mTimerSensor->isScheduled())
				mTimerSensor->unschedule();
			mRotFirstIndex = 0;
			mRotLastIndex = -1;

			// set focal plane as projection plane
			SbMatrix m;
			m = getCamera()->orientation.getValue();
			SbVec3f dir(-m[2][0], -m[2][1], -m[2][2]);
			SbVec3f focalPoint = getCamera()->position.getValue() + dir * getCamera()->focalDistance.getValue();
			mPlaneProj->setPlane(SbPlane(dir, focalPoint));
			mPlaneProj->setViewVolume(mViewVolume);

			// set sphere sheet starting point
			mSphereSheetProj->project(getMousePosNormalized(action));

			mLastMousePos = getMousePosNormalized(action);
			mMouseDownPos = mLastMousePos;
			mDragStartMouse = mPlaneProj->project(mLastMousePos);
			mDragStartCameraPos = getCamera()->position.getValue();
			mRotLastNormPos = mLastMousePos - SbVec2f(0.5, 0.5);

			switch (mode.getValue())
			{
			case PANZOOM:	mDragStartMouseBorder = !isVecInObjectSpace(SbVec3f((mLastMousePos[0] * 2) - 1, (mLastMousePos[1] * 2) - 1, 0), 0.6); break;
			case ROTATE:	mDragStartMouseBorder = (mLastMousePos[0] > 0.9) || (mLastMousePos[1] > 0.9) || (mLastMousePos[0] < 0.1) || (mLastMousePos[1] < 0.1); break;
			default:
				mDragStartMouseBorder = FALSE;
			}

			action->setGrabber(this);

			updateCursor();

			handled = TRUE;
		}
	}
	else if (e->isOfType(SoLocation2Event::getClassTypeId()))
	{
		if (action->getGrabber() == this)
		{
			handled = TRUE;

			SoComplexity *complexityPtr = (SoComplexity*) getAnyPart("complexity", TRUE);
			if (complexityPtr->value.getValue() != 0.249)
			{
				complexityPtr->value.setValue(0.249f);
			}			
			
			if ((e->getTime() - mLastHandleEventTime).getValue() > 0.25)
			{
				mRotFirstIndex = 0;
				mRotLastIndex = -1;
			}

			switch (mode.getValue())
			{
			case PANZOOM:	if (mDragStartMouseBorder)
								scaleCam(1.f + (mLastMousePos[1] - getMousePosNormalized(action)[1]));
							else
								panCam(getMousePosNormalized(action));
							break;
			case ROTATE:	if (mDragStartMouseBorder)
								spinNormCam(getMousePosNormalized(action));
							else
								spinCam(getMousePosNormalized(action));
							break;
			case ROTATE_PLANE:
							mouseRotatePlane(getMousePosNormalized(action));
							break;
			case TRANSLATE_PLANE:
							mouseTranslatePlane(getMousePosNormalized(action));
							break;
			default:
				handled = FALSE;
			}

			mLastMousePos = getMousePosNormalized(action);
		}
		else if (!action->isHandled())
		{
			mLastMousePos = getMousePosNormalized(action);
			if ((mLastMousePos[0] >= 0.f) && (mLastMousePos[0] <= 1.f) &&
				(mLastMousePos[1] >= 0.f) && (mLastMousePos[1] <= 1.f))
			{
				switch (mode.getValue())
				{
				case PANZOOM:	mDragStartMouseBorder = !isVecInObjectSpace(SbVec3f((mLastMousePos[0] * 2) - 1, (mLastMousePos[1] * 2) - 1, 0), 0.6); break;
				case ROTATE:	mDragStartMouseBorder = (mLastMousePos[0] > 0.9) || (mLastMousePos[1] > 0.9) || (mLastMousePos[0] < 0.1) || (mLastMousePos[1] < 0.1); break;
				default:
					mDragStartMouseBorder = FALSE;
				}

				if (mode.getValue() != NONE)
				{
					updateCursor();
					action->setHandled();
				}
			}
		}
	}
	else if (SoMouseButtonEvent::isButtonReleaseEvent(e, mDragMouseButton) && (action->getGrabber() == this)) 
	{
		action->releaseGrabber();
		handled = TRUE;

		if (pointTo.getValue() && (mLastMousePos == mMouseDownPos))
		{
			// release button position equals push button position: scroll to cursor
			scrollToCursor(action);
			SoComplexity *complexityPtr = (SoComplexity*) getAnyPart("complexity", TRUE);
			complexityPtr->value.setValue(0.5);
			complexityPtr->textureQuality.setValue(0.5);
		}
		else
		{
			if ((e->getTime() - mLastHandleEventTime).getValue() > 0.25)
			{
				mRotFirstIndex = 0;
				mRotLastIndex = -1;
			}
			
			float averageAngle, angle;
			SbVec3f averageAxis, axis;

			// get number of samples
			int num = (((mRotLastIndex - mRotFirstIndex) + 1 + ROT_BUFF_SIZE) % ROT_BUFF_SIZE);

			// check for not enough samples
			if (num >= 2 && autoSpin.getValue()) 
			{
				// get average axis of rotation
				// ??? right now only take one sample
				mRotBuffer[mRotFirstIndex].getValue(averageAxis, angle);

				// get average angle of rotation
				averageAngle = 0;
				for (int i=0; i<num; i++) 
				{
					int n = (mRotFirstIndex + i) % ROT_BUFF_SIZE;
					mRotBuffer[n].getValue(axis, angle);
					averageAngle += angle;
				}
				averageAngle /= float(num);
				//averageAngle /= 2.0f;

				mAutoSpinRotation.setValue(averageAxis, averageAngle);
				mTimerSensor->schedule();
			}
			else
			{
				SoComplexity *complexityPtr = (SoComplexity*) getAnyPart("complexity", TRUE);
				complexityPtr->value.setValue(0.5);
				complexityPtr->textureQuality.setValue(0.5);
			}
		}
	}

	if (handled)
	{
		action->setHandled();
		mLastHandleEventTime = e->getTime();
	}
}


void SoXipExaminer::panCam(const SbVec2f pos)
{
	getCamera()->position = mDragStartCameraPos + (mDragStartMouse - mPlaneProj->project(pos));
}


void SoXipExaminer::scaleCam(float scale)
{
	getCamera()->scaleHeight(scale);

	if (getCamera()->isOfType(SoPerspectiveCamera::getClassTypeId()))
	{
		float ha = ((SoPerspectiveCamera*) getCamera())->heightAngle.getValue();
		if (ha > 3.0)
		{
			((SoPerspectiveCamera*) getCamera())->heightAngle.setValue(3.0);
		}
		if (ha < 0.1)
		{
			((SoPerspectiveCamera*) getCamera())->heightAngle.setValue(0.1);
		}
	}
	else if (getCamera()->isOfType(SoOrthographicCamera::getClassTypeId()))
	{
		float h = ((SoOrthographicCamera*) getCamera())->height.getValue();

		SbMatrix m = viewBoundingBox.getValue();
		float maxHeight = 0.f;
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++)
				if (m[i][j] > maxHeight)
					maxHeight = m[i][j];

		if (h > (10.f * maxHeight))
		{
			((SoOrthographicCamera*) getCamera())->height.setValue(10.f * maxHeight);
		}

		if (h < (0.1f * maxHeight))
		{
			((SoOrthographicCamera*) getCamera())->height.setValue(0.1f * maxHeight);
		}
	}
}


void SoXipExaminer::rotateCam(const SbRotation &rot)
{
	// get center of rotation
	SbRotation camRot = getCamera()->orientation.getValue();
	float radius = getCamera()->focalDistance.getValue();
	SbMatrix m;
	m = camRot;
	SbVec3f dir(-m[2][0], -m[2][1], -m[2][2]);
	SbVec3f center = getCamera()->position.getValue() + dir * radius;

	// apply new rotation to the camera
	camRot = rot * camRot;
	getCamera()->orientation = camRot;

	// reposition camera to look at pt of interest
	m = camRot;
	dir.setValue(-m[2][0], -m[2][1], -m[2][2]);
	getCamera()->position = center - dir * radius;
}


void SoXipExaminer::spinCam(const SbVec2f pos)
{
	// find rotation and rotate camera
	SbRotation rot;
	mSphereSheetProj->projectAndGetRotation(pos, rot);
	rot.invert();

	rotateCam(rot);

	// save rotation for animation
	mRotLastIndex = ((mRotLastIndex+1) % ROT_BUFF_SIZE);
	mRotBuffer[mRotLastIndex] = rot;

	// check if queue is full
	if (((mRotLastIndex+1) % ROT_BUFF_SIZE) == mRotFirstIndex)
	mRotFirstIndex = ((mRotFirstIndex+1) % ROT_BUFF_SIZE);
}

void SoXipExaminer::spinNormCam(const SbVec2f pos)
{
	SbVec2f norm = pos - SbVec2f(0.5, 0.5);
	
	SbVec3f from, to;
	from = SbVec3f(mRotLastNormPos[0], mRotLastNormPos[1], 0.f);
	to = SbVec3f(norm[0], norm[1], 0);

	SbRotation rot(from, to);
	rot.invert();
	rotateCam(rot);

	mRotLastNormPos = norm;
}

// --------------------------------------------------------------------------
//! used to rotate the plane
// --------------------------------------------------------------------------
void SoXipExaminer::rotatePlane(const SbRotation &rot)
{
	// change the plane equation by transforming it with a rotation matrix
	SbVec3f center;
	viewBoundingBox.getValue().multVecMatrix(SbVec3f(0.5f, 0.5f, 0.5f), center);

	SbPlane tmpPlane(plane.getValue());

	SbMatrix tmpMat;
	tmpMat.makeIdentity();

	tmpMat.setTransform(SbVec3f(0, 0, 0), rot, SbVec3f(1, 1, 1), SbRotation(1, 1, 1, 1), center);

	tmpPlane.transform(tmpMat);
	plane.setValue(tmpPlane);
}


// --------------------------------------------------------------------------
//! used to translate the plane
// --------------------------------------------------------------------------
void SoXipExaminer::translatePlane(const SbVec3f &tvec)
{
	// change the plane equation by transforming it with a translation matrix

	// change the plane equation by transforming it with a rotation matrix
	SbVec3f center, minVec, maxVec;
	viewBoundingBox.getValue().multVecMatrix(SbVec3f(0.5f, 0.5f, 0.5f), center);	
	viewBoundingBox.getValue().multVecMatrix(SbVec3f(0.f, 0.f, 0.f), minVec);	
	viewBoundingBox.getValue().multVecMatrix(SbVec3f(1.0f, 1.0f, 1.0f), maxVec);	
	
	SbPlane tmpPlane(plane.getValue());

	SbVec3f planeCenter;
	tmpPlane.intersect(SbLine(center, center + tmpPlane.getNormal()), planeCenter);

	float xc, yc, zc, xmin, ymin, zmin, xmax, ymax, zmax, xcur, ycur, zcur;

	planeCenter.getValue(xc, yc, zc);
	tvec.getValue(xcur, ycur, zcur);

	minVec.getValue(xmin, ymin, zmin);
	maxVec.getValue(xmax, ymax, zmax);

	// test if the plane is still containing in the bounding box 
	if( (xc + xcur < xmin) ||
		(yc + ycur < ymin) ||
		(zc + zcur < zmin) ||
		(xc + xcur > xmax) ||
		(yc + ycur > ymax) ||
		(zc + zcur > zmax))
			return;


	SbMatrix tmpMat;
	tmpMat.makeIdentity();

	tmpMat.setTranslate(tvec);

	tmpPlane.transform(tmpMat);
	plane.setValue(tmpPlane);
}

//--------------------------------------------------------------------------
//! called whenever the scene is rendered
//--------------------------------------------------------------------------
void SoXipExaminer::mouseRotatePlane(const SbVec2f &mousePos)
{
	SbVec3f center, minVec, maxVec;
	viewBoundingBox.getValue().multVecMatrix(SbVec3f(0.5f, 0.5f, 0.5f), center);	
	viewBoundingBox.getValue().multVecMatrix(SbVec3f(0.f, 0.f, 0.f), minVec);	
	viewBoundingBox.getValue().multVecMatrix(SbVec3f(1.0f, 1.0f, 1.0f), maxVec);	

	// use a projector to translate the mouse position and rotate the plane using the mouse motion 
	SbSphere boxSphere;
	boxSphere.circumscribe(SbBox3f(minVec, maxVec));
	boxSphere.setRadius(boxSphere.getRadius()/1.5);


	SbSphereSheetProjector sProjector(boxSphere);
	sProjector.setViewVolume(mViewVolume);
	sProjector.setWorkingSpace(mViewTransform);

	SbRotation Prot;

	sProjector.projectAndGetRotation(mLastMousePos, Prot);
	sProjector.projectAndGetRotation(mousePos, Prot);

	rotatePlane(Prot);
}

//--------------------------------------------------------------------------
//! translate the plane with the mouse
//--------------------------------------------------------------------------
void SoXipExaminer::mouseTranslatePlane(const SbVec2f &mousePos)
{
	// use a projector to translate the mouse position and translate the plane using the mouse motion 
	SbVec3f center, norm;
	viewBoundingBox.getValue().multVecMatrix(SbVec3f(0.5f, 0.5f, 0.5f), center);	

	SbLineProjector pProjector;
	pProjector.setViewVolume(mViewVolume);
	pProjector.setWorkingSpace(mViewTransform);

	norm = plane.getValue().getNormal();

	SbVec3f z = mViewVolume.zVector();
	float dot = z.dot(norm);

	if (fabs(dot) > 0.95)
	{
		// plane is almost orthogonal to viewer, navigate with up/down movement
		float delta = (mLastMousePos[1] - mousePos[1]) / 2.0f;

		SbVec3f h = mViewVolume.ulf.getValue();
		h -= mViewVolume.llf.getValue();

		z.normalize();
		z *= h.length();;
		z *= delta;
		translatePlane(z);
	}
	else
	{
		// navigate plane to new mouse position in 3-D
		pProjector.setLine(SbLine(center, center + norm));

		SbVec3f mouseVec = pProjector.getVector(mLastMousePos, mousePos);
		translatePlane(mouseVec);
	}
}


void SoXipExaminer::scrollToCursor(SoHandleEventAction *action)
{
	SoRayPickAction pa(mVpRegion);
	pa.setPoint(action->getEvent()->getPosition());

	pa.setRadius(3);
	pa.enableCulling(FALSE);
	pa.apply(action->getNodeAppliedTo());
	const SoPickedPoint *pickedPoint = pa.getPickedPoint();

	if (pickedPoint)
	{
		SbVec3f pt = pickedPoint->getPoint();
		SoXipExaminer::pickedPoint.setValue(pt);
	}
}
