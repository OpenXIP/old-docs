#include <xip/inventor/core/SoXipOrientationCube.h>
#include <Inventor/elements/SoViewportRegionElement.h>
#include <Inventor/elements/SoViewVolumeElement.h>
#include <Inventor/actions/SoGLRenderAction.h>
#include <Inventor/SbLinear.h>
#include <GL/gl.h>


///////////////////////////////////////////////////////////////////////

#define IS_FACE(v, x, y, z)	((v[0] * x + v[1] * y + v[2] * z) > -0.00001)


static void drawGLLetter(char letter)
{
	const double myScale = 0.5;

	glPushMatrix();

	switch(letter)
	{
	case 'F':
		glScaled(0.6, 1.0, 1.0);
		glBegin(GL_LINES);
			glVertex3d( -0.7 * myScale, -0.7 * myScale, -1.0 * myScale);
			glVertex3d(  0.7 * myScale, -0.7 * myScale, -1.0 * myScale);
			glVertex3d( -0.7 * myScale, -0.7 * myScale, -1.0 * myScale);
			glVertex3d( -0.7 * myScale,  0.7 * myScale, -1.0 * myScale);
			glVertex3d( -0.7 * myScale,  0.0 * myScale, -1.0 * myScale);
			glVertex3d(  0.2 * myScale,  0.0 * myScale, -1.0 * myScale);
		glEnd();
	break;

	case 'H':
		glScaled(0.6, 1.0, 1.0);
		glBegin(GL_LINES);
 		    glVertex3d( 0.7 * myScale, 0.7 * myScale,  1.0 * myScale);
		    glVertex3d( 0.7 * myScale, -0.7 * myScale, 1.0 * myScale);
		    glVertex3d(-0.7 * myScale, 0.7 * myScale,   1.0 * myScale );
		    glVertex3d(-0.7 * myScale, -0.7 * myScale, 1.0 * myScale );
		    glVertex3d(-0.7 * myScale, 0.0, 1.0 * myScale);
		    glVertex3d( 0.7 * myScale ,  0.0, 1.0 * myScale);
 		    glVertex3d( -0.7 * myScale, 0.7 * myScale,  1.0 * myScale);
		    glVertex3d( -1.1 * myScale, 0.7 * myScale, 1.0 * myScale);
		glEnd();
	break;

	case 'L':
		glScaled(1.0, 0.6, 1.0);
		glRotated(90, 1, 0, 0);
		glBegin(GL_LINES);
 		    glVertex3d( 1.0 * myScale ,  0.7 * myScale , 0.7 * myScale );
		    glVertex3d( 1.0 * myScale , -0.7 * myScale , 0.7 * myScale );		
		    glVertex3d( 1.0 * myScale , -0.7 * myScale , 0.7 * myScale );
		    glVertex3d( 1.0 * myScale , -0.7 * myScale , -0.7 * myScale );		
		glEnd();
	break;

	case 'R':
		glScaled(1.0, 0.6, 1.0);
		glRotated(90, 1, 0, 0);
		glBegin(GL_LINES);
			glVertex3d( -1.0 * myScale , 0.7 * myScale ,  -0.7 * myScale );
			glVertex3d( -1.0 * myScale , 0.7 * myScale , 0.0);
			glVertex3d( -1.0 * myScale , 0.0,  -0.7 * myScale );
			glVertex3d( -1.0 * myScale , 0.0, 0.0);
			glVertex3d( -1.0 * myScale , 0.7 * myScale , -0.7 * myScale );
			glVertex3d( -1.0 * myScale , -0.7 * myScale , -0.7 * myScale );
			glVertex3d( -1.0 * myScale , 0.0, -0.7 * myScale );
			glVertex3d( -1.0 * myScale , -0.7 * myScale , 0.7 * myScale );
		glEnd();

		//Semi circle for completion //
		// Needs improvement
		glBegin(GL_LINE_STRIP);
			glNormal3d( -myScale,  0.0,  0.0);
			glVertex3d( -1.0 * myScale , 0.7 * myScale , 0.0);
			glVertex3d( -1.0 * myScale , 0.6 * myScale , 0.35 * myScale );
			glVertex3d( -1.0 * myScale , 0.45 * myScale , 0.6 * myScale );
			glVertex3d( -1.0 * myScale , 0.35 * myScale , 0.7 * myScale );
			glVertex3d( -1.0 * myScale , 0.25 * myScale , 0.6 * myScale );
			glVertex3d( -1.0 * myScale , 0.10 * myScale , 0.35 * myScale );
			glVertex3d( -1.0 * myScale , 0.0, 0.0);		
		glEnd();
	break;

	case 'A':
		glScaled(0.6, 1.0, 1.0);
		glRotated(180, 0, 1, 0);
		glBegin(GL_LINES);
			glVertex3d( 0.0 , -1.0 * myScale ,  -0.7 * myScale );
			glVertex3d( -0.7 * myScale , -1.0 * myScale , 0.7 * myScale );		
			glVertex3d( 0.0, -1.0 * myScale ,  -0.7 * myScale );
			glVertex3d( 0.7 * myScale , -1.0 * myScale , 0.7 * myScale );		
			glVertex3d(  -.35 * myScale , -1.0 * myScale , -0.0 * myScale );
			glVertex3d(  0.35 * myScale ,  -1.0 * myScale , -0.0);		
		glEnd();
	break;

	case 'P':
		glScaled(0.6, 1.0, 1.0);
		glRotated(-90, 0, 1, 0);
		glBegin(GL_LINE_STRIP);
			glVertex3d(  0.7 * myScale , 1.0 * myScale , 0.0);
			glVertex3d(  0.6 * myScale , 1.0 * myScale , 0.35 * myScale );
			glVertex3d(  0.45 * myScale , 1.0 * myScale , 0.6 * myScale );
			glVertex3d(  0.35 * myScale , 1.0 * myScale , 0.7 * myScale );
			glVertex3d(  0.25 * myScale , 1.0 * myScale , 0.6 * myScale );
			glVertex3d(  0.10 * myScale , 1.0 * myScale , 0.35 * myScale );
			glVertex3d(  0.0, 1.0 * myScale , 0.0);		
		glEnd();

		glBegin(GL_LINES);
			glVertex3d( -0.7 * myScale , 1.0 * myScale ,  -0.7 * myScale );
			glVertex3d(  0.7 * myScale , 1.0 * myScale ,  -0.7 * myScale );		
			glVertex3d(  0.7 * myScale , 1.0 * myScale , 0.0 * myScale );
			glVertex3d(  0.7 * myScale , 1.0 * myScale ,  -0.7 * myScale );		
			glVertex3d(  0.0 * myScale , 1.0 * myScale , 0.0 * myScale );
			glVertex3d(  0.0 * myScale , 1.0 * myScale ,  -0.7 * myScale );		
		glEnd();
	break;
	}

	glPopMatrix();
}


static void drawLetterBoundingBox(const SbRotation &rot, const SbVec3f &cameraOrientation, bool front, int primitive, int side, int letters)
{
	double tmp;
	double norm[3];

	// half lengths are used here
	double width = .5;
	double height = .5;
	double depth = .5;

	// read rotation
	norm[0] = -cameraOrientation[0];
	norm[1] = -cameraOrientation[1];
	norm[2] = -cameraOrientation[2];

	SbVec3f axis;
	float radians;
	rot.getValue(axis, radians);
	glRotatef(radians / M_PI * 180.f, axis[0], axis[1], axis[2]);

	if (side & 1)
	{
		// top / bottom
		tmp = IS_FACE(norm, 0, 1, 0) == front ? height : -height;
		glBegin(primitive);
		glVertex3d(-width, tmp, -depth);
		glVertex3d(+width, tmp, -depth);
		glVertex3d(+width, tmp, +depth);
		glVertex3d(-width, tmp, +depth);
		glEnd();

		if (front && letters)
		{
			if (tmp == height)
			{
				drawGLLetter('P');
			}
			else
			{
				drawGLLetter('A');
			}
		}
	}

	if (side & 2)
	{
		// left / right
		tmp = IS_FACE(norm, 1, 0, 0) == front ? width : -width;
		glBegin(primitive);
		glVertex3d(tmp, -height, -depth);
		glVertex3d(tmp, +height, -depth);
		glVertex3d(tmp, +height, +depth);
		glVertex3d(tmp, -height, +depth);
		glEnd();

		if (front && letters)
		{
			if (tmp == width)
			{
				drawGLLetter('L');
			}
			else
			{
				drawGLLetter('R');
			}
		}
	}

	if (side & 4)
	{
		// rear / front
		tmp = IS_FACE(norm, 0, 0, 1) == front ? depth : -depth;
		glBegin(primitive);
		glVertex3d(-width, -height, tmp);
		glVertex3d(-width, +height, tmp);
		glVertex3d(+width, +height, tmp);
		glVertex3d(+width, -height, tmp);
		glEnd();

		if (front && letters)
		{
			if (tmp == depth)
			{
				drawGLLetter('H');
			}
			else
			{
				drawGLLetter('F');
			}
		}
	}
}

///////////////////////////////////////////////////////////////////////





SO_NODE_SOURCE(SoXipOrientationCube);

void SoXipOrientationCube::initClass()
{
	SO_NODE_INIT_CLASS(SoXipOrientationCube, SoNode, "Node");
}

SoXipOrientationCube::SoXipOrientationCube()
{
	SO_NODE_CONSTRUCTOR(SoXipOrientationCube);
}

SoXipOrientationCube::~SoXipOrientationCube()
{
}

void SoXipOrientationCube::GLRender(SoGLRenderAction * action)
{
	int i;

	SbViewportRegion viewportRegion = SoViewportRegionElement::get(action->getState());
	SbVec2s s = viewportRegion.getViewportSizePixels();

	// get the camera orientation
	SbViewVolume vVol = SoViewVolumeElement::get(action->getState());

	SbMatrix affine, proj;
	SbVec3f trans, scale;
	SbRotation rot, so;

	vVol.getMatrices(affine, proj);
	affine.getTransform(trans, rot, scale, so);

	glPushAttrib(GL_TRANSFORM_BIT | GL_ENABLE_BIT | GL_LINE_BIT | GL_CURRENT_BIT);
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_ALPHA_TEST);

	// disable clip planes
	int maxClipPlanes;
	glGetIntegerv(GL_MAX_CLIP_PLANES, &maxClipPlanes);
	maxClipPlanes = min(maxClipPlanes, 16);
	for (i = 0; i < maxClipPlanes; i++)
	{
		glDisable(GL_CLIP_PLANE0 + i);
	}

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	glLineWidth(1);
	glDisable(GL_LINE_STIPPLE);
	glColor3f(0.75f, 0.75f, 0.2f);
	glTranslatef(0.7, -0.7, 0.);
	float aspectRatio = viewportRegion.getViewportAspectRatio();
	float cubeSize = 0.15;
	if (aspectRatio < 1.0)
		cubeSize *= aspectRatio;

	glScalef(cubeSize / aspectRatio, cubeSize, cubeSize);
	drawLetterBoundingBox(rot, vVol.getProjectionDirection(), true, GL_LINE_LOOP, 7, true);

	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();

	glMatrixMode(GL_MODELVIEW);

	glPopAttrib();
}



