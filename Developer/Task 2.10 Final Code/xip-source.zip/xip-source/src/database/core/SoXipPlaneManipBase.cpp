//
// This implementation is based on an SGI example code (LineManip.cpp), which was
// found in the internet. See end of file for copyright notice.
//
#include <xip/inventor/core/SoXipPlaneManipBase.h>
#include <Inventor/projectors/SbPlaneProjector.h>
#include <Inventor/misc/SoState.h>
#include <Inventor/actions/SoHandleEventAction.h>
#include <Inventor/events/SoLocation2Event.h>
#include <Inventor/elements/SoViewportRegionElement.h>
#include <Inventor/elements/SoViewVolumeElement.h>

SO_NODE_SOURCE(SoXipPlaneManipBase);

//
// Constructor; sets up scene graph
//
SoXipPlaneManipBase::SoXipPlaneManipBase()
{
	SO_NODE_CONSTRUCTOR(SoXipPlaneManipBase);

	mDragMouseButton = SoMouseButtonEvent::BUTTON1;
	mHandleEventAction = NULL;
	mPlaneProj = new SbPlaneProjector(FALSE);
	mPlaneProj->setPlane(SbPlane(SbVec3f(0, 0, 1), 0));

	SO_NODE_ADD_FIELD(isManipulating, (FALSE));
}


//
// Destructor.  This will be called when this is unref'ed.
//
SoXipPlaneManipBase::~SoXipPlaneManipBase()
{
	delete mPlaneProj;
}


//
// Magic stuff to register this node with the database
//
void SoXipPlaneManipBase::initClass()
{
	// do not tell SoType that we are derived from "Group" to
	// prevent users from adding children to this node
	SO_NODE_INIT_CLASS(SoXipPlaneManipBase, SoGroup, "Node");
}


//
// For setting the plane that the manip works in. You pass it a normal.
//
void SoXipPlaneManipBase::setPlane(const SbPlane &plane)
{
	mPlaneProj->setPlane(plane);
}


//
// Updates projectors to the given point (plane remains the same).
//
void SoXipPlaneManipBase::updateProjectors(const SbVec3f &curPt)
{
	SbVec3f dir = mPlaneProj->getPlane().getNormal();
	mPlaneProj->setPlane(SbPlane(dir, curPt));
}


//
// Does the grunt work of projecting the mouse onto the plane
//
SbVec3f SoXipPlaneManipBase::getMouseProjection()
{
	const SoEvent *e = mHandleEventAction->getEvent();

	// If we're grabbing, we've already got our view parameters.
	// If not, then we'd better get them now.
	// NOTE: If you're grabbing and you try to get view parameters, you'll
	//       get a bad answer. Grabbing causes you to skip over camera
	//       nodes directly to this one. So the state has no valid view info.
	if (mHandleEventAction->getGrabber() != this)
	{
		extractViewingParams(mHandleEventAction);
	}

	mPlaneProj->setViewVolume(mViewVolume);
	return mPlaneProj->project(e->getNormalizedPosition(mVpRegion));
}


void SoXipPlaneManipBase::handleEvent(SoHandleEventAction *action)
{
	SbBool handled = FALSE;
	const SoEvent *e = action->getEvent();

	mHandleEventAction = action;

	if (SoMouseButtonEvent::isButtonPressEvent(e, mDragMouseButton) && !e->wasShiftDown() && !e->wasCtrlDown())
	{
		handled = dragBegin();
	}
	else if (e->isOfType(SoLocation2Event::getClassTypeId()) && (action->getGrabber() == this)) 
	{
		handled = dragMove();
	}
	else if (SoMouseButtonEvent::isButtonReleaseEvent(e, mDragMouseButton) && (action->getGrabber() == this)) 
	{
		handled = dragEnd();
	}

	if (handled)
	{
		action->setHandled();
	}
}

SbBool SoXipPlaneManipBase::dragBegin()
{
//	mHandleEventAction->setGrabber(this);
//	isManipulating.setValue(TRUE);

	return FALSE;
}


SbBool SoXipPlaneManipBase::dragMove()
{
	if (!isManipulating.getValue())
	{
		isManipulating.setValue(TRUE);
	}

	return TRUE;
}


SbBool SoXipPlaneManipBase::dragEnd()
{
	mHandleEventAction->releaseGrabber();
	isManipulating.setValue(FALSE);

	return TRUE;
}


void SoXipPlaneManipBase::extractViewingParams(SoHandleEventAction *ha)
{
	if (!ha) 
	{
		// If the action is NULL, use default values for view info.
		mViewVolume.ortho(-1, 1, -1, 1, 1, 10);
		mVpRegion = SbViewportRegion(1, 1);
	}
	else 
	{
		// Get the view info from the action.
		SoState *state = ha->getState();
		mViewVolume = SoViewVolumeElement::get(state);
		mVpRegion = SoViewportRegionElement::get(state);
	}
}


SbVec2f SoXipPlaneManipBase::getMousePosNormalized()
{
	const SoEvent *e = mHandleEventAction->getEvent();

	if (mHandleEventAction->getGrabber() != this)
	{
		extractViewingParams(mHandleEventAction);
	}

	return e->getNormalizedPosition(mVpRegion);
}


/*
 * Copyright (c) 1991-95 Silicon Graphics, Inc.
 *
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that the name of Silicon Graphics may not be used in any advertising or
 * publicity relating to the software without the specific, prior written
 * permission of Silicon Graphics.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL SILICON GRAPHICS BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT ADVISED OF THE
 * POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

/*
 * Copyright (C) 1994, Silicon Graphics, Inc.
 * All Rights Reserved.
 *
 * This is UNPUBLISHED PROPRIETARY SOURCE CODE of Silicon Graphics, Inc.;
 * the contents of this file may not be disclosed to third parties, copied or
 * duplicated in any form, in whole or in part, without the prior written
 * permission of Silicon Graphics, Inc.
 *
 * RESTRICTED RIGHTS LEGEND:
 * Use, duplication or disclosure by the Government is subject to restrictions
 * as set forth in subdivision (c)(1)(ii) of the Rights in Technical Data
 * and Computer Software clause at DFARS 252.227-7013, and/or in similar or
 * successor clauses in the FAR, DOD or NASA FAR Supplement. Unpublished -
 * rights reserved under the Copyright Laws of the United States.
 */
