#include <Inventor/errors/SoErrors.h>
#include <xip/inventor/core/SoXipMultiTextureElement.h>
#include <xip/inventor/core/SoXipLutElement.h>
#include <xip/inventor/core/SbXipImage.h>

#include <inventor/elements/SoGLTextureEnabledElement.h>

#include <windows.h>
#include <gl/gl.h>
#include <xip/inventor/core/SoXipLutTexture.h>


SO_NODE_SOURCE(SoXipLutTexture);

/**
 *	Constructor
 */	
SoXipLutTexture::SoXipLutTexture()
{
	SO_NODE_CONSTRUCTOR(SoXipLutTexture);
	m_imagePtr = 0;
	m_textureInitialized = false;
	m_textureId = 0;
    m_lutId = 0;
}

/**
 *	Destructor
 */	
SoXipLutTexture::~SoXipLutTexture()
{
	deleteTexture();
}

/**
 *	Delete the OpenGL texture
 */	
void SoXipLutTexture::deleteTexture()
{
	if( m_textureId != -1 )
	{
		glDeleteTextures( 1, &m_textureId );
		m_textureInitialized = false;
	}
}

/**	
 *	Initializes the class
 */
void SoXipLutTexture::initClass()
{
	SO_NODE_INIT_CLASS(SoXipLutTexture, SoNode,  "Node");
	SO_ENABLE(SoGLRenderAction,	SoXipMultiTextureElement);
	SO_ENABLE(SoGLRenderAction, SoXipLutElement);
}

/**
 *	Upload the OpenGL texture in video memory
 */	
void SoXipLutTexture::loadTexture()
{
	if( !m_imagePtr || !m_imagePtr->get() )
	{
		SoDebugError::post( __FILE__, "No image input" );
		return ;
	}

	SbXipImage* img = m_imagePtr->get();
	//	Get the number of elements
	int totLutElements = img->getDimStored()[0];

	if( img->getType() != SbXipImage::FLOAT ||
		img->getComponentLayoutType() != SbXipImage::RGBA )
	{
		SoDebugError::post( __FILE__, "Invalid LUT Image: expect RGBA Float" );
		return ;
	}

	//	Get the pixel buffer of the LUT
	const float* xipLutBuffer = (float *) img->refBufferPtr();
	char *imgBuffer = 0;
    
    try
    {
        int lutSize16 = 1 << 16;
        imgBuffer = new char[4*lutSize16];

		//	Copy the LUT elements to a new buffer
	    for( int i = 0; i < lutSize16; i ++)
	    {
            // rescale to 16-bits and pre-multiply by alpha
            int index = int(i * (totLutElements / double(lutSize16)));
		    imgBuffer[ 4*i ] = xipLutBuffer[4*index] * xipLutBuffer[4*index+3] * 255;
		    imgBuffer[ 4*i+1 ] = xipLutBuffer[4*index+1] * xipLutBuffer[4*index+3] * 255;
		    imgBuffer[ 4*i+2 ] = xipLutBuffer[4*index+2] * xipLutBuffer[4*index+3] * 255;
		    imgBuffer[ 4*i+3 ] = xipLutBuffer[4*index+3] * 255;
	    }

	    glGenTextures(1, &m_textureId);
	    glBindTexture(GL_TEXTURE_2D, m_textureId);
 
		//	Create and upload the OpenGL texture
	    glTexImage2D(
		       GL_TEXTURE_2D,		// target
		       0,					// level
		       GL_RGBA8,			// internal
		       256,		// width
		       256,					// height
		       0,					// border
		       GL_RGBA,				// format
		       GL_UNSIGNED_BYTE,	// type
		       imgBuffer);

	    delete[] imgBuffer;
        imgBuffer = 0;

		//	set the texture parameters for OpenGL
	    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

	    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    	
	    img->unrefBufferPtr();
	    m_textureInitialized = true;
	
    }

	
    catch (...)
    {
        delete [] imgBuffer;
        throw;
    }
}

void SoXipLutTexture::GLRender(SoGLRenderAction *action)
{
	if( !action->getState() )
		return ;

    try
    {
		//	Get the current LUT element
	    SoXipDataImage* image = (SoXipDataImage *) SoXipLutElement::get( action->getState() );
    	
	    if (image)
	    {
		    if(!image->isOfType( SoXipDataImage::getClassTypeId() ) )
		    {
			    SoDebugError::post( __FILE__, "Invalid Lut Image" );
			    return ;
		    }
		    glPushAttrib( GL_ENABLE_BIT );

			//	Enable OpenInventor texture
		    SoGLTextureEnabledElement::set( action->getState(), TRUE );

			//	New LUT
		    if (image->getDataId() != m_lutId)
		    {
				//	delete the previous one if it exists
			    if( m_imagePtr && m_textureInitialized )
				    deleteTexture();

			    m_imagePtr = image;
				//	load new texture
			    loadTexture();

			    // update lut id for next time
			    m_lutId = image->getDataId();
		    }

			//	Bind texture
		    glEnable( GL_TEXTURE_2D );
		    //glBindTexture(GL_TEXTURE_2D, m_textureId);
			SoXipMultiTextureElement::bindTexture(action->getState(), GL_TEXTURE_2D, m_textureId);
		    glPopAttrib();
	    }
    }
	//	Is anything wrong ?

    catch(...)
    {
        SoDebugError::post( __FILE__, "Unknown Exception" );

        return;
    }
}