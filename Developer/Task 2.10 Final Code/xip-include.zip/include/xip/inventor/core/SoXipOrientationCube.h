#ifndef SOXIPORIENTATIONCUBE_H
#define SOXIPORIENTATIONCUBE_H

#include <Inventor/nodes/SoSubNode.h>


class SoXipOrientationCube : public SoNode
{
SO_NODE_HEADER(SoXipOrientationCube);

public:
	/// Static method providing Open Inventor runtype type information.
	static void initClass();

	///	Default constructor
	SoXipOrientationCube();

protected:
	/// Default destructor
	virtual ~SoXipOrientationCube();

protected:
	virtual void GLRender(SoGLRenderAction * action);
};


#endif // SOXIPORIENTATIONCUBE_H
