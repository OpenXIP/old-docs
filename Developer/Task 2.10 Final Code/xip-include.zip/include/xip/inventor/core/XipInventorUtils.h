#ifndef XIPINVENTORUTILS_H
#define XIPINVENTORUTILS_H

#include <xip/inventor/core/xipivcore.h>
#include <Inventor/SbLinear.h>
#include <Inventor/SoType.h>
#include <Inventor/SbString.h>


#define XIP_FLT_EPSILON	0.0001

#define XIP_DOACTION_HEADER()												\
	protected:																\
	virtual void doAction(SoAction * action);								\
	virtual void GLRender(SoGLRenderAction * action) { doAction(action); }	\
	virtual void callback(SoCallbackAction * action) { doAction(action); }	\
	virtual void pick(SoPickAction * action) { doAction(action); }			\
	virtual void getBoundingBox(SoGetBoundingBoxAction * action) { doAction(action); }


class SoPath;
class SoNode;


class XIPIVCORE_API XipGeomUtils
{
public:
	// computes the intersection line of two planes
	static SbBool planeIntersect(const SbPlane & p1, const SbPlane & p2, SbLine & line);

	// computes the intersection point of three planes
	static SbBool planeIntersect(const SbPlane &p1, const SbPlane &p2, const SbPlane &p3, SbVec3f &point);

	// returns a SbPlane object for a given model matrix
	static SbPlane planeFromMatrix(const SbMatrix &m);

	// returns the angle between the two vectors
	static float angleBetweenVectors(SbVec3f vectorA, SbVec3f vectorB);

	// computes the two end points of the intersection line of two MPR planes
	static SbBool mprIntersect(const SbMatrix & m1, const SbMatrix & m2, SbVec3f line[2], float viewportAspectRatio);

	// computes translation of a plane along it's normal given any 3-D
	// translation of the intersection position
	static SbMatrix translatePlaneNormal(SbMatrix plane, SbVec3f translation);

	// checks if vector is located within (-1,-1 to 1,1) space.
	static SbBool isVecInObjectSpace(const SbVec3f &vec, float halfLen = 1.0);

	// computes the default orthogonal orientations
	static int orthoOrientations(const SbMatrix &orientation, SbMatrix &orthoF, SbMatrix &orthoL, SbMatrix &orthoA);
};

// utility class to convert string into unicode string
class XIPIVCORE_API radWStringConv
{
public:
	radWStringConv(const char *str);
	radWStringConv();
	virtual ~radWStringConv();
	const wchar_t *getString() const;

protected:
	wchar_t *mStr;
};

// expands environment variables (e.g. "$(RAD)") in a string
XIPIVCORE_API SbString radStrExpandEnv(const char *strIn);


#endif // XIPINVENTORUTILS_H
