#ifndef SOXIPDOGEAR_H
#define SOXIPDOGEAR_H

#include <Inventor/nodes/SoSubNode.h>
#include <Inventor/fields/SoSFTrigger.h>
#include <Inventor/SbViewportRegion.h>

class SoTimerSensor;
class SoSensor;

class SoXipDogEar : public SoNode
{
SO_NODE_HEADER(SoXipDogEar);

public:
	SoSFTrigger next;
	SoSFTrigger previous;

	/// Static method providing Open Inventor runtype type information.
	static void initClass();

	///	Default constructor
	SoXipDogEar();

protected:
	/// Default destructor
	virtual ~SoXipDogEar();
	virtual int getDogEarSize(const SbViewportRegion &viewportRegion);

protected:
	virtual void rayPick (SoRayPickAction *action);
	virtual void GLRender(SoGLRenderAction * action);
	virtual void handleEvent (SoHandleEventAction *action);
	virtual void timer(SoSensor *sensor);

	SoTimerSensor *mTimerSensor;
	SbBool mForwardDirection;
	SbVec2s mMouseDownPosition;

private:
	static void timerSensorCBFunc(void *usr, SoSensor *sensor);
};


#endif // SOXIPDOGEAR_H
